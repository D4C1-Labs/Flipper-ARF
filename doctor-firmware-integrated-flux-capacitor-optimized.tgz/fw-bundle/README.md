# Doctor Firmware - Integrated with CVMr Car Protocols & Flux Capacitor Support

## Overview

This is an optimized integrated firmware build combining:
- **doctor-firmware (doctor-005)**: 94+ SubGhz protocols
- **CVMr-ARF car protocols**: 7 additional automotive protocols (Audi, Chrysler, GM, Honda Acura, Mercedes, Nissan, Toyota/Lexus)
- **Flux Capacitor support**: Native RF amplifier/transmitter integration
- **TX Enabled**: All 101 protocols support both RX (receive) and TX (transmit)
- **Optimized**: Removed non-essential BadUSB app to free space

## Build Information

- **Platform**: Flipper Zero (F7)
- **Target**: STM32WB55 MCU
- **Flash Size**: 824 KB (optimized - 1.57 KB free)
- **Build Date**: November 12, 2026 (optimized version)
- **Protocol Count**: 101 total protocols
- **Optimization**: BadUSB app removed, space freed for future expansion

## Included Automotive Protocols

### New CVMr-ARF Additions:
- **Audi** - Audi/Volkswagen Group vehicles
- **Chrysler** - Chrysler, Dodge, Jeep vehicles
- **GM** - General Motors vehicles (GM Onstar, etc.)
- **Honda Acura** - Honda and Acura vehicles
- **Mercedes** - Mercedes-Benz vehicles
- **Nissan** - Nissan and Infiniti vehicles
- **Toyota/Lexus** - Toyota and Lexus vehicles

### Original Doctor-Firmware Protocols:
Includes all standard SubGhz protocols (Princeton, KeeLoq, Nice FLO, etc.) plus automotive protocols:
- Ford (V0-V3)
- Fiat (V0, V1, V2 via Hitag2)
- Kia (V0-V7)
- Honda (Static, V1, V2)
- Renault (V0, V1 via Hitag2)
- Mazda (V0, V2)
- Mercedes (V0, V1)
- BMW
- VAG (Volkswagen Group)
- And many more...

## Flux Capacitor Support

The firmware includes native support for the Flux Capacitor RF amplifier/transmitter device:
- Automatic device detection and registration
- Full TX capability with RF amplification
- CC1101 external radio module integration
- Seamless protocol compatibility

### Using Flux Capacitor:
1. Connect Flux Capacitor to Flipper's SPI/GPIO expansion port
2. Power on Flipper
3. Navigate to SubGhz → Settings → Device
4. Select "Flux Capacitor" or "CC1101 External" as the transmitter
5. Use any supported protocol for TX/RX operations

## TX Enabled

All 101 protocols in this firmware support transmission (TX):
- Car key fob operations (lock/unlock, etc.)
- Rolling code protocols
- Frequency modulation and hopping
- Amplitude shift keying (ASK)

**IMPORTANT**: Use responsibly and legally. Transmitting on SubGhz frequencies may be illegal in some jurisdictions without proper authorization.

## Removed Features

**BadUSB Application**: Removed to optimize flash usage
- HID keyboard emulation no longer available
- Script execution capability removed
- Freed ~424 bytes of flash memory for future use

**Rationale**: BadUSB is not related to SubGhz/automotive protocols. Removing it freed space while maintaining all core SubGhz functionality.

## Files Included

- **firmware.bin** - Binary format for DFU flashing
- **firmware.dfu** - DFU format (Device Firmware Upgrade)
- **README.md** - This documentation

## Flashing Instructions

### Option 1: Using Flipper Zero Official Updater (Recommended)
1. Download the firmware file (firmware.bin or firmware.dfu)
2. Place on Flipper's SD card in `/updates/` folder
3. Open Flipper → Settings → System → Firmware Update
4. Select the firmware file and proceed

### Option 2: Using qFlipper or Web Updater
1. Connect Flipper to computer via USB
2. Open qFlipper or official web updater
3. Select firmware.dfu
4. Click "Start flashing"

### Option 3: Command Line (Linux/Mac)
```bash
# Using dfu-util
dfu-util -d 0483:df11 -a 0 -D firmware.dfu

# Or using STM32CubeProgrammer
STM32_Programmer.sh -c port=USB1 -d firmware.bin -Rst
```

## System Requirements

- Flipper Zero with STM32WB55 MCU
- SD card (optional, for storage)
- USB cable (for flashing)
- Computer with flashing tools (qFlipper recommended)

## Protocol Features

### RX (Receive) Capabilities
- Decode SubGhz signals from RF devices
- Support for rolling codes and hopping algorithms
- Automatic protocol detection
- Save and analyze captured signals

### TX (Transmit) Capabilities
- Transmit using selected protocol (101 protocols available)
- Modulation support: ASK, FSK, OOK, etc.
- Frequency selection
- Power level adjustment (if supported by Flux Capacitor)
- Rolling code emulation

## Notes

- This firmware is provided AS-IS without warranty
- Use only for authorized testing and research
- Follow all applicable laws and regulations
- Some protocols may have restrictions in certain countries
- Transmitting without authorization is illegal in most jurisdictions
- BadUSB functionality is not available in this build

## Build Information

- **Base Firmware**: doctor-firmware (doctor-005 branch)
- **Integration**: CVMr-ARF automotive protocols
- **Optimizations**: 
  - Removed BadUSB app (freed 424 bytes)
  - Added 7 automotive protocols
  - Integrated Flux Capacitor device support
  - Enabled TX on all protocols
  - Optimized for 824 KB flash memory limit

## Support & References

- Flipper Zero Official: https://flipperzero.one/
- Flux Capacitor: https://lab401.com/products/flux-capacitor
- SubGhz Protocol Documentation: See Flipper documentation
- doctor-firmware: https://github.com/thedoctorz/doctor-firmware

## Firmware Statistics

```
Protocol Summary:
- Total Protocols: 101
- Automotive: 7 (CVMr-ARF) + 8+ (original)
- General RF: 85+
- TX Support: All
- Flux Capacitor: Enabled
- Flash Used: 98.81% (1.57 KB free)
- Applications: 11 (BadUSB removed)
```

## Changelog

### Optimized Build (Nov 12, 2026 - v2)
- Removed BadUSB application to free space
- Freed 424 bytes of additional flash memory
- Improved space margin for future updates
- All SubGhz functionality preserved

### Initial Build (Nov 12, 2026)
- Integrated CVMr-ARF 7 automotive protocols
- Added Flux Capacitor native support
- Enabled TX for all protocols
- Created distribution package

---

**Last Updated**: November 12, 2026
**Version**: doctor-005-integrated-cvmr-flux-capacitor-optimized
**Status**: Production Ready ✅
