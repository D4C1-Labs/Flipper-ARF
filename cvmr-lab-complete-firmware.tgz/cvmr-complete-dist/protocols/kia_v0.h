#pragma once

#include "base.h"

// [PROTOPIRATE_PORT] File ported from ProtoPirate kia_v0 (multi-type KIA/SUZUKI/HONDA).
// Exported symbol names preserved for ARF registry/catalog compatibility.

#define SUBGHZ_PROTOCOL_KIA_V0_NAME "KIA/HYU V0"

// [PROTOPIRATE_PORT] Sub-type identifiers exposed for deserialization/UI
#define KIA_V0_SUBTYPE_KIA    1U
#define KIA_V0_SUBTYPE_SUZUKI 2U
#define KIA_V0_SUBTYPE_HONDA  3U

typedef struct SubGhzProtocolDecoderKIA SubGhzProtocolDecoderKIA;
typedef struct SubGhzProtocolEncoderKIA SubGhzProtocolEncoderKIA;

extern const SubGhzProtocolDecoder subghz_protocol_kia_decoder;
extern const SubGhzProtocolEncoder subghz_protocol_kia_encoder;
extern const SubGhzProtocol subghz_protocol_kia_v0;

/**
 * Allocate SubGhzProtocolEncoderKIA.
 * @param environment Pointer to a SubGhzEnvironment instance
 * @return SubGhzProtocolEncoderKIA* pointer to a SubGhzProtocolEncoderKIA instance
 */
void* subghz_protocol_encoder_kia_alloc(SubGhzEnvironment* environment);

/**
 * Free SubGhzProtocolEncoderKIA.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 */
void subghz_protocol_encoder_kia_free(void* context);

/**
 * Deserialize and generating an upload to send.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 * @param flipper_format Pointer to a FlipperFormat instance
 * @return status
 */
SubGhzProtocolStatus
    subghz_protocol_encoder_kia_deserialize(void* context, FlipperFormat* flipper_format);

/**
 * Forced transmission stop.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 */
void subghz_protocol_encoder_kia_stop(void* context);

/**
 * Getting the level and duration of the upload to be loaded into DMA.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 * @return LevelDuration
 */
LevelDuration subghz_protocol_encoder_kia_yield(void* context);

/**
 * Set button value for encoding.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 * @param button Button value (0-15, masked to type)
 */
void subghz_protocol_encoder_kia_set_button(void* context, uint8_t button);

/**
 * Set counter value for encoding.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 * @param counter Counter value (0-65535)
 */
void subghz_protocol_encoder_kia_set_counter(void* context, uint16_t counter);

/**
 * Increment counter by 1.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 */
void subghz_protocol_encoder_kia_increment_counter(void* context);

/**
 * Get current counter value.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 * @return Current counter value
 */
uint16_t subghz_protocol_encoder_kia_get_counter(void* context);

/**
 * Get current button value.
 * @param context Pointer to a SubGhzProtocolEncoderKIA instance
 * @return Current button value
 */
uint8_t subghz_protocol_encoder_kia_get_button(void* context);

/**
 * Allocate SubGhzProtocolDecoderKIA.
 * @param environment Pointer to a SubGhzEnvironment instance
 * @return SubGhzProtocolDecoderKIA* pointer to a SubGhzProtocolDecoderKIA instance
 */
void* subghz_protocol_decoder_kia_alloc(SubGhzEnvironment* environment);

/**
 * Free SubGhzProtocolDecoderKIA.
 * @param context Pointer to a SubGhzProtocolDecoderKIA instance
 */
void subghz_protocol_decoder_kia_free(void* context);

/**
 * Reset decoder SubGhzProtocolDecoderKIA.
 * @param context Pointer to a SubGhzProtocolDecoderKIA instance
 */
void subghz_protocol_decoder_kia_reset(void* context);

/**
 * Parse a raw sequence of levels and durations received from the air.
 * @param context Pointer to a SubGhzProtocolDecoderKIA instance
 * @param level Signal level true-high false-low
 * @param duration Duration of this level in, us
 */
void subghz_protocol_decoder_kia_feed(void* context, bool level, uint32_t duration);

/**
 * Getting the hash sum of the last randomly received parcel.
 * @param context Pointer to a SubGhzProtocolDecoderKIA instance
 * @return hash Hash sum (uint8_t)
 */
uint8_t subghz_protocol_decoder_kia_get_hash_data(void* context);

/**
 * Serialize data SubGhzProtocolDecoderKIA.
 * @param context Pointer to a SubGhzProtocolDecoderKIA instance
 * @param flipper_format Pointer to a FlipperFormat instance
 * @param preset The modulation on which the signal was received, SubGhzRadioPreset
 * @return status
 */
SubGhzProtocolStatus subghz_protocol_decoder_kia_serialize(
    void* context,
    FlipperFormat* flipper_format,
    SubGhzRadioPreset* preset);

/**
 * Deserialize data SubGhzProtocolDecoderKIA.
 * @param context Pointer to a SubGhzProtocolDecoderKIA instance
 * @param flipper_format Pointer to a FlipperFormat instance
 * @return status
 */
SubGhzProtocolStatus
    subghz_protocol_decoder_kia_deserialize(void* context, FlipperFormat* flipper_format);

/**
 * Getting a textual representation of the received data.
 * @param context Pointer to a SubGhzProtocolDecoderKIA instance
 * @param output Resulting text
 */
void subghz_protocol_decoder_kia_get_string(void* context, FuriString* output);
