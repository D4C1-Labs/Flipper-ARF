#pragma once

#include "base.h"

#include <furi.h>

/*
 * Keeloq
 * https://ru.wikipedia.org/wiki/KeeLoq
 * https://phreakerclub.com/forum/showthread.php?t=1094
 *
 */
#define KEELOQ_NLF 0x3A5C742E

/*
 * KeeLoq learning types
 * https://phreakerclub.com/forum/showthread.php?t=67
 */
#define KEELOQ_LEARNING_UNKNOWN             0u
#define KEELOQ_LEARNING_SIMPLE              1u
#define KEELOQ_LEARNING_NORMAL              2u
#define KEELOQ_LEARNING_SECURE              3u
#define KEELOQ_LEARNING_MAGIC_XOR_TYPE_1    4u
#define KEELOQ_LEARNING_FAAC                5u
#define KEELOQ_LEARNING_MAGIC_SERIAL_TYPE_1 6u
#define KEELOQ_LEARNING_MAGIC_SERIAL_TYPE_2 7u
#define KEELOQ_LEARNING_MAGIC_SERIAL_TYPE_3 8u
// #define BENINCA_ARC_KEY_TYPE 9u -- RESERVED
#define KEELOQ_LEARNING_SIMPLE_KINGGATES    10u
#define KEELOQ_LEARNING_NORMAL_JAROLIFT     11u
// [UNLEASHED_PORT] New learning types
#define KEELOQ_LEARNING_ERREKA              12u
#define KEELOQ_LEARNING_PUJOL               13u
#define KEELOQ_LEARNING_AERF                14u
#define KEELOQ_LEARNING_SIMPLE_JCM          15u

/**
 * Simple Learning Encrypt
 * @param data - 0xBSSSCCCC, B(4bit) key, S(10bit) serial&0x3FF, C(16bit) counter
 * @param key - manufacture (64bit)
 * @return keeloq encrypt data
 */
uint32_t subghz_protocol_keeloq_common_encrypt(const uint32_t data, const uint64_t key);

/** 
 * Simple Learning Decrypt
 * @param data - keeloq encrypt data
 * @param key - manufacture (64bit)
 * @return 0xBSSSCCCC, B(4bit) key, S(10bit) serial&0x3FF, C(16bit) counter
 */
uint32_t subghz_protocol_keeloq_common_decrypt(const uint32_t data, const uint64_t key);

/** 
 * Normal Learning
 * @param data - serial number (28bit)
 * @param key - manufacture (64bit)
 * @return manufacture for this serial number (64bit)
 */
uint64_t subghz_protocol_keeloq_common_normal_learning(uint32_t data, const uint64_t key);

/** 
 * Secure Learning
 * @param data - serial number (28bit)
 * @param seed - seed number (32bit)
 * @param key - manufacture (64bit)
 * @return manufacture for this serial number (64bit)
 */
uint64_t
    subghz_protocol_keeloq_common_secure_learning(uint32_t data, uint32_t seed, const uint64_t key);

/** 
 * Magic_xor_type1 Learning
 * @param data - serial number (28bit)
 * @param xor - magic xor (64bit)
 * @return manufacture for this serial number (64bit)
 */
uint64_t subghz_protocol_keeloq_common_magic_xor_type1_learning(uint32_t data, uint64_t xor);

/** Faac SLH (Spa) Learning
 * @param seed - seed number (32bit)
 * @param key - mfkey (64bit)
 * @return man_learning for this fix number (64bit)
 */
uint64_t subghz_protocol_keeloq_common_faac_learning(const uint32_t seed, const uint64_t key);

/** Magic_serial_type1 Learning
 * @param data - serial number (28bit)
 * @param man - magic man (64bit)
 * @return manufacture for this serial number (64bit)
 */

uint64_t subghz_protocol_keeloq_common_magic_serial_type1_learning(uint32_t data, uint64_t man);

/** Magic_serial_type2 Learning
 * @param data - btn+serial number (32bit)
 * @param man - magic man (64bit)
 * @return manufacture for this serial number (64bit)
 */

uint64_t subghz_protocol_keeloq_common_magic_serial_type2_learning(uint32_t data, uint64_t man);

/** Magic_serial_type3 Learning
 * @param data - btn+serial number (32bit)
 * @param man - magic man (64bit)
 * @return manufacture for this serial number (64bit)
 */

uint64_t subghz_protocol_keeloq_common_magic_serial_type3_learning(uint32_t data, uint64_t man);

// [UNLEASHED_PORT] Protocol (Manufacturer) specific learning
// TODO: Better documentation for these functions

uint64_t subghz_protocol_keeloq_common_learning_aerf(uint32_t data, const uint64_t key);

uint64_t
    subghz_protocol_keeloq_common_learning_erreka(uint32_t data, uint32_t mix, const uint64_t key);

uint64_t subghz_protocol_keeloq_common_learning_pujol(uint32_t data, const uint64_t key);

// Utils
uint32_t subghz_protocol_keeloq_common_decrypt_derived(
    uint32_t hop_encrypted,
    uint64_t derived_manufacturing_key,
    uint32_t outer_limit);
