#include "nord_ice.h"
#include "../blocks/const.h"
#include "../blocks/decoder.h"
#include "../blocks/encoder.h"
#include "../blocks/generic.h"
#include "../blocks/math.h"
#include "common.h"

// [PROTOPIRATE_PORT] custom_btn support
#include "../blocks/custom_btn_i.h"

#define TAG "SubGhzProtocolNord_Ice"

static const SubGhzBlockConst subghz_protocol_nord_ice_const = {
    .te_short = 300,
    .te_long = 800,
    .te_delta = 150,
    .min_count_bit_for_found = 33,
};

struct SubGhzProtocolDecoderNord_Ice {
    SubGhzProtocolDecoderBase base;

    SubGhzBlockDecoder decoder;
    SubGhzBlockGeneric generic;
};
SUBGHZ_ASSERT_DECODER_COMMON_LAYOUT(SubGhzProtocolDecoderNord_Ice);

struct SubGhzProtocolEncoderNord_Ice {
    SubGhzProtocolEncoderBase base;

    SubGhzProtocolBlockEncoder encoder;
    SubGhzBlockGeneric generic;
};
SUBGHZ_ASSERT_ENCODER_GENERIC_LAYOUT(SubGhzProtocolEncoderNord_Ice);

typedef enum {
    Nord_IceDecoderStepReset = 0,
    Nord_IceDecoderStepSaveDuration,
    Nord_IceDecoderStepCheckDuration,
} Nord_IceDecoderStep;

const SubGhzProtocolDecoder subghz_protocol_nord_ice_decoder = {
    .alloc = subghz_protocol_decoder_nord_ice_alloc,
    .free = subghz_protocol_decoder_common_free,

    .feed = subghz_protocol_decoder_nord_ice_feed,
    .reset = subghz_protocol_decoder_common_reset,

    .get_hash_data = subghz_protocol_decoder_common_get_hash_data,
    .serialize = subghz_protocol_decoder_common_serialize,
    .deserialize = subghz_protocol_decoder_nord_ice_deserialize,
    .get_string = subghz_protocol_decoder_nord_ice_get_string,
};

const SubGhzProtocolEncoder subghz_protocol_nord_ice_encoder = {
    .alloc = subghz_protocol_encoder_nord_ice_alloc,
    .free = subghz_protocol_encoder_common_free,

    .deserialize = subghz_protocol_encoder_nord_ice_deserialize,
    .stop = subghz_protocol_encoder_common_stop,
    .yield = subghz_protocol_encoder_common_yield,
};

const SubGhzProtocol subghz_protocol_nord_ice = {
    .name = SUBGHZ_PROTOCOL_NORD_ICE_NAME,
    .type = SubGhzProtocolTypeStatic,
    .flag = SubGhzProtocolFlag_433 | SubGhzProtocolFlag_AM | SubGhzProtocolFlag_Decodable |
            SubGhzProtocolFlag_Load | SubGhzProtocolFlag_Save | SubGhzProtocolFlag_Send,

    .decoder = &subghz_protocol_nord_ice_decoder,
    .encoder = &subghz_protocol_nord_ice_encoder,
};

void* subghz_protocol_encoder_nord_ice_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);
    return subghz_protocol_encoder_common_alloc(
        sizeof(SubGhzProtocolEncoderNord_Ice), &subghz_protocol_nord_ice, 3, 128);
}

static void subghz_protocol_nord_ice_check_remote_controller(SubGhzBlockGeneric* instance);

/**
 * Generating an upload from data.
 * @param context Pointer to a SubGhzProtocolEncoderNord_Ice instance
 * @return true Always; this encoder has no failure path
 */
static bool subghz_protocol_encoder_nord_ice_get_upload(void* context) {
    SubGhzProtocolEncoderNord_Ice* instance = context;
    furi_assert(instance);

    subghz_protocol_nord_ice_check_remote_controller(&instance->generic);
    size_t index = 0;

    // Send key and GAP
    for(uint8_t i = instance->generic.data_count_bit; i > 0; i--) {
        if(bit_read(instance->generic.data, i - 1)) {
            // Send bit 1
            instance->encoder.upload[index++] =
                level_duration_make(true, (uint32_t)subghz_protocol_nord_ice_const.te_long);
            if(i == 1) {
                //Send gap if bit was last
                instance->encoder.upload[index++] = level_duration_make(
                    false, (uint32_t)subghz_protocol_nord_ice_const.te_short * 25);
            } else {
                instance->encoder.upload[index++] =
                    level_duration_make(false, (uint32_t)subghz_protocol_nord_ice_const.te_short);
            }
        } else {
            // Send bit 0
            instance->encoder.upload[index++] =
                level_duration_make(true, (uint32_t)subghz_protocol_nord_ice_const.te_short);
            if(i == 1) {
                //Send gap if bit was last
                instance->encoder.upload[index++] = level_duration_make(
                    false, (uint32_t)subghz_protocol_nord_ice_const.te_short * 25);
            } else {
                instance->encoder.upload[index++] =
                    level_duration_make(false, (uint32_t)subghz_protocol_nord_ice_const.te_long);
            }
        }
    }

    instance->encoder.size_upload = index;
    return true;
}

/** 
 * Analysis of received data
 * @param instance Pointer to a SubGhzBlockGeneric* instance
 */
static void subghz_protocol_nord_ice_check_remote_controller(SubGhzBlockGeneric* instance) {
    instance->serial = (instance->data >> 15) << 9 |
                       (instance->data & 0x1FF); // 26 bits for serial
    instance->btn = (instance->data >> 9) & 0x3F; // 6 bits for button
}

SubGhzProtocolStatus
    subghz_protocol_encoder_nord_ice_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_assert(context);
    SubGhzProtocolEncoderNord_Ice* instance = context;

    SubGhzProtocolStatus ret = subghz_block_generic_deserialize_check_count_bit(
        &instance->generic,
        flipper_format,
        subghz_protocol_nord_ice_const.min_count_bit_for_found);
    if(ret != SubGhzProtocolStatusOk) {
        return ret;
    }
    // Optional value
    flipper_format_read_uint32(
        flipper_format, "Repeat", (uint32_t*)&instance->encoder.repeat, 1);

    // [PROTOPIRATE_PORT] custom_btn support
    // Nord ICE button codes (from decoder key samples, 6-bit field at data>>9 & 0x3F):
    //   btn1 = 0x34 Lock, btn2 = 0x18 Unlock, btn3 = 0x31 Trunk, btn4 = 0x32 Panic.
    subghz_protocol_nord_ice_check_remote_controller(&instance->generic);
    {
        const uint8_t original_btn = (uint8_t)(instance->generic.btn & 0x3FU);
        if(subghz_custom_btn_get_original() == 0) {
            subghz_custom_btn_set_original(original_btn);
        }
        subghz_custom_btn_set_max(4);
        uint8_t custom_btn_id = subghz_custom_btn_get();
        uint8_t new_btn = original_btn;
        switch(custom_btn_id) {
        case SUBGHZ_CUSTOM_BTN_UP:    new_btn = 0x34U; break; // Lock
        case SUBGHZ_CUSTOM_BTN_OK:    new_btn = original_btn; break;
        case SUBGHZ_CUSTOM_BTN_DOWN:  new_btn = 0x18U; break; // Unlock
        case SUBGHZ_CUSTOM_BTN_LEFT:  new_btn = 0x31U; break; // Trunk
        case SUBGHZ_CUSTOM_BTN_RIGHT: new_btn = 0x32U; break; // Panic
        default:                      new_btn = original_btn; break;
        }
        if(new_btn != original_btn) {
            // Re-pack the 6-bit button field (bits 9..14) into generic.data.
            instance->generic.data =
                (instance->generic.data & ~((uint64_t)0x3FU << 9U)) |
                ((uint64_t)(new_btn & 0x3FU) << 9U);
            instance->generic.btn = new_btn & 0x3FU;
        }
    }

    if(!subghz_protocol_encoder_nord_ice_get_upload(instance)) {
        return SubGhzProtocolStatusErrorEncoderGetUpload;
    }
    instance->encoder.is_running = true;
    return ret;
}

void* subghz_protocol_decoder_nord_ice_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);
    return subghz_protocol_decoder_common_alloc(
        sizeof(SubGhzProtocolDecoderNord_Ice), &subghz_protocol_nord_ice);
}

void subghz_protocol_decoder_nord_ice_feed(void* context, bool level, volatile uint32_t duration) {
    furi_assert(context);
    SubGhzProtocolDecoderNord_Ice* instance = context;

    // Nord ICE Decoder
    // 2026.03 - @xMasterX (MMX)

    // Key samples
    //
    //                      Serial          Btn    Serial
    // 0x9467688A btn 1 = 10010100011001110 110100 010001010
    // 0x9467308A btn 2 = 10010100011001110 011000 010001010
    // 0x9467628A btn 3 = 10010100011001110 110001 010001010
    // 0x9467648A btn 4 = 10010100011001110 110010 010001010

    switch(instance->decoder.parser_step) {
    case Nord_IceDecoderStepReset:
        if((!level) && (DURATION_DIFF(duration, subghz_protocol_nord_ice_const.te_short * 25) <
                        subghz_protocol_nord_ice_const.te_delta * 11)) {
            //Found GAP
            instance->decoder.decode_data = 0;
            instance->decoder.decode_count_bit = 0;
            instance->decoder.parser_step = Nord_IceDecoderStepSaveDuration;
        }
        break;
    case Nord_IceDecoderStepSaveDuration:
        if(level) {
            instance->decoder.te_last = duration;
            instance->decoder.parser_step = Nord_IceDecoderStepCheckDuration;
        } else {
            instance->decoder.parser_step = Nord_IceDecoderStepReset;
        }
        break;
    case Nord_IceDecoderStepCheckDuration:
        if(!level) {
            // Bit 0 is short and long timing = 300us HIGH (te_last) and 800us LOW
            if((DURATION_DIFF(instance->decoder.te_last, subghz_protocol_nord_ice_const.te_short) <
                subghz_protocol_nord_ice_const.te_delta) &&
               (DURATION_DIFF(duration, subghz_protocol_nord_ice_const.te_long) <
                subghz_protocol_nord_ice_const.te_delta)) {
                subghz_protocol_blocks_add_bit(&instance->decoder, 0);
                instance->decoder.parser_step = Nord_IceDecoderStepSaveDuration;
                // Bit 1 is long and short timing = 800us HIGH (te_last) and 300us LOW
            } else if(
                (DURATION_DIFF(instance->decoder.te_last, subghz_protocol_nord_ice_const.te_long) <
                 subghz_protocol_nord_ice_const.te_delta) &&
                (DURATION_DIFF(duration, subghz_protocol_nord_ice_const.te_short) <
                 subghz_protocol_nord_ice_const.te_delta)) {
                subghz_protocol_blocks_add_bit(&instance->decoder, 1);
                instance->decoder.parser_step = Nord_IceDecoderStepSaveDuration;
            } else if(
                // End of the key
                DURATION_DIFF(duration, subghz_protocol_nord_ice_const.te_short * 25) <
                subghz_protocol_nord_ice_const.te_delta * 11) {
                //Found next GAP and add bit 0 or 1 (only bit 0 was found on the remotes)
                if((DURATION_DIFF(
                        instance->decoder.te_last, subghz_protocol_nord_ice_const.te_short) <
                    subghz_protocol_nord_ice_const.te_delta)) {
                    subghz_protocol_blocks_add_bit(&instance->decoder, 0);
                }
                if((DURATION_DIFF(
                        instance->decoder.te_last, subghz_protocol_nord_ice_const.te_long) <
                    subghz_protocol_nord_ice_const.te_delta)) {
                    subghz_protocol_blocks_add_bit(&instance->decoder, 1);
                }
                // If got 33 bits key reading is finished
                if(instance->decoder.decode_count_bit ==
                   subghz_protocol_nord_ice_const.min_count_bit_for_found) {
                    instance->generic.data = instance->decoder.decode_data;
                    instance->generic.data_count_bit = instance->decoder.decode_count_bit;
                    if(instance->base.callback)
                        instance->base.callback(&instance->base, instance->base.context);
                }
                instance->decoder.decode_data = 0;
                instance->decoder.decode_count_bit = 0;
                instance->decoder.parser_step = Nord_IceDecoderStepReset;
            } else {
                instance->decoder.parser_step = Nord_IceDecoderStepReset;
            }
        } else {
            instance->decoder.parser_step = Nord_IceDecoderStepReset;
        }
        break;
    }
}

SubGhzProtocolStatus
    subghz_protocol_decoder_nord_ice_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_assert(context);
    SubGhzProtocolDecoderNord_Ice* instance = context;
    return subghz_block_generic_deserialize_check_count_bit(
        &instance->generic,
        flipper_format,
        subghz_protocol_nord_ice_const.min_count_bit_for_found);
}

void subghz_protocol_decoder_nord_ice_get_string(void* context, FuriString* output) {
    furi_assert(context);
    SubGhzProtocolDecoderNord_Ice* instance = context;

    subghz_protocol_nord_ice_check_remote_controller(&instance->generic);

    // for future use
    // // push protocol data to global variable
    // subghz_block_generic_global.btn_is_available = false;
    // subghz_block_generic_global.current_btn = instance->generic.btn;
    // subghz_block_generic_global.btn_length_bit = 4;
    // //

    furi_string_cat_printf(
        output,
        "%s %dbit\r\n"
        "Key:0x%08llX\r\n"
        "SN:0x%lX Btn:%X\r\n",
        instance->generic.protocol_name,
        instance->generic.data_count_bit,
        (uint64_t)(instance->generic.data & 0xFFFFFFFFF),
        instance->generic.serial,
        instance->generic.btn);
}
