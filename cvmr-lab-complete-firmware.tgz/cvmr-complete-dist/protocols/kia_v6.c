#include "kia_v6.h"
#include "../blocks/const.h"
#include "../blocks/decoder.h"
#include "../blocks/encoder.h"
#include "../blocks/generic.h"
#include "../blocks/math.h"
#include "../blocks/custom_btn_i.h"
#include <lib/toolbox/manchester_decoder.h>
#include <string.h>

#define TAG "SubGhzProtocolKiaV6"

#define KIA_V6_XOR_MASK_LOW  0x84AF25FB
#define KIA_V6_XOR_MASK_HIGH 0x638766AB

#define KIA_V6_PREAMBLE_PAIRS_1  640
#define KIA_V6_PREAMBLE_PAIRS_2  38
#define KIA_V6_UPLOAD_SIZE       2000

static const SubGhzBlockConst subghz_protocol_kia_v6_const = {
    .te_short = 200,
    .te_long = 400,
    .te_delta = 100,
    .min_count_bit_for_found = 144,
};

static const uint8_t aes_sbox[256] = {
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab,
    0x76, 0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4,
    0x72, 0xc0, 0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71,
    0xd8, 0x31, 0x15, 0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2,
    0xeb, 0x27, 0xb2, 0x75, 0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6,
    0xb3, 0x29, 0xe3, 0x2f, 0x84, 0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb,
    0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf, 0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45,
    0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8, 0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5,
    0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2, 0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44,
    0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73, 0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a,
    0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb, 0xe0, 0x32, 0x3a, 0x0a, 0x49,
    0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, 0xe7, 0xc8, 0x37, 0x6d,
    0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08, 0xba, 0x78, 0x25,
    0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a, 0x70, 0x3e,
    0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e, 0xe1,
    0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb,
    0x16};

static const uint8_t aes_sbox_inv[256] = {
    0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7,
    0xfb, 0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde,
    0xe9, 0xcb, 0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42,
    0xfa, 0xc3, 0x4e, 0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49,
    0x6d, 0x8b, 0xd1, 0x25, 0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c,
    0xcc, 0x5d, 0x65, 0xb6, 0x92, 0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15,
    0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84, 0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7,
    0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06, 0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02,
    0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b, 0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc,
    0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73, 0x96, 0xac, 0x74, 0x22, 0xe7, 0xad,
    0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e, 0x47, 0xf1, 0x1a, 0x71, 0x1d,
    0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b, 0xfc, 0x56, 0x3e, 0x4b,
    0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4, 0x1f, 0xdd, 0xa8,
    0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f, 0x60, 0x51,
    0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef, 0xa0,
    0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
    0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c,
    0x7d};

static const uint8_t aes_rcon[10] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36};

struct SubGhzProtocolDecoderKiaV6 {
    SubGhzProtocolDecoderBase base;
    SubGhzBlockDecoder decoder;
    SubGhzBlockGeneric generic;
    uint16_t header_count;

    ManchesterState manchester_state;

    uint32_t data_part1_low;
    uint32_t data_part1_high;

    uint32_t stored_part1_low;
    uint32_t stored_part1_high;
    uint32_t stored_part2_low;
    uint32_t stored_part2_high;
    uint16_t data_part3;

    uint8_t bit_count;
    uint8_t fx_field;
    uint8_t crc1_field;
    uint8_t crc2_field;
};

struct SubGhzProtocolEncoderKiaV6 {
    SubGhzProtocolEncoderBase base;
    SubGhzProtocolBlockEncoder encoder;
    SubGhzBlockGeneric generic;
    uint32_t stored_part1_low;
    uint32_t stored_part1_high;
    uint32_t stored_part2_low;
    uint32_t stored_part2_high;
    uint16_t data_part3;
    uint8_t fx_field;
};

typedef enum {
    KiaV6DecoderStepReset = 0,
    KiaV6DecoderStepWaitFirstHigh,
    KiaV6DecoderStepCountPreamble,
    KiaV6DecoderStepWaitLongHigh,
    KiaV6DecoderStepData,
} KiaV6DecoderStep;

#define kia_v6_crc8(data, len) subghz_protocol_blocks_crc8((data), (len), 0x07, 0xFF)

static uint8_t gf_mul2(uint8_t x) {
    return ((x >> 7) * 0x1b) ^ (x << 1);
}

static void aes_subbytes_inv(uint8_t* state) {
    for(int row = 0; row < 4; row++) {
        for(int col = 0; col < 4; col++) {
            state[row + col * 4] = aes_sbox_inv[state[row + col * 4]];
        }
    }
}

static void aes_shiftrows_inv(uint8_t* state) {
    uint8_t temp;

    temp = state[13];
    state[13] = state[9];
    state[9] = state[5];
    state[5] = state[1];
    state[1] = temp;

    temp = state[2];
    state[2] = state[10];
    state[10] = temp;
    temp = state[6];
    state[6] = state[14];
    state[14] = temp;

    temp = state[3];
    state[3] = state[7];
    state[7] = state[11];
    state[11] = state[15];
    state[15] = temp;
}

static void aes_mixcolumns_inv(uint8_t* state) {
    uint8_t a, b, c, d;
    for(int i = 0; i < 4; i++) {
        a = state[i * 4];
        b = state[i * 4 + 1];
        c = state[i * 4 + 2];
        d = state[i * 4 + 3];

        uint8_t a2 = gf_mul2(a);
        uint8_t a4 = gf_mul2(a2);
        uint8_t a8 = gf_mul2(a4);
        uint8_t b2 = gf_mul2(b);
        uint8_t b4 = gf_mul2(b2);
        uint8_t b8 = gf_mul2(b4);
        uint8_t c2 = gf_mul2(c);
        uint8_t c4 = gf_mul2(c2);
        uint8_t c8 = gf_mul2(c4);
        uint8_t d2 = gf_mul2(d);
        uint8_t d4 = gf_mul2(d2);
        uint8_t d8 = gf_mul2(d4);

        state[i * 4] = (a8 ^ a4 ^ a2) ^ (b8 ^ b2 ^ b) ^ (c8 ^ c4 ^ c) ^ (d8 ^ d);
        state[i * 4 + 1] = (a8 ^ a) ^ (b8 ^ b4 ^ b2) ^ (c8 ^ c2 ^ c) ^ (d8 ^ d4 ^ d);
        state[i * 4 + 2] = (a8 ^ a4 ^ a) ^ (b8 ^ b) ^ (c8 ^ c4 ^ c2) ^ (d8 ^ d2 ^ d);
        state[i * 4 + 3] = (a8 ^ a2 ^ a) ^ (b8 ^ b4 ^ b) ^ (c8 ^ c) ^ (d8 ^ d4 ^ d2);
    }
}

static void aes_addroundkey(uint8_t* state, const uint8_t* round_key) {
    for(int col = 0; col < 4; col++) {
        state[col * 4] ^= round_key[col * 4];
        state[col * 4 + 1] ^= round_key[col * 4 + 1];
        state[col * 4 + 2] ^= round_key[col * 4 + 2];
        state[col * 4 + 3] ^= round_key[col * 4 + 3];
    }
}

static void aes_subbytes(uint8_t* state) {
    for(int row = 0; row < 4; row++) {
        for(int col = 0; col < 4; col++) {
            state[row + col * 4] = aes_sbox[state[row + col * 4]];
        }
    }
}

static void aes_shiftrows(uint8_t* state) {
    uint8_t temp;
    temp = state[1];
    state[1] = state[5];
    state[5] = state[9];
    state[9] = state[13];
    state[13] = temp;
    temp = state[2];
    state[2] = state[10];
    state[10] = temp;
    temp = state[6];
    state[6] = state[14];
    state[14] = temp;
    temp = state[3];
    state[3] = state[15];
    state[15] = state[11];
    state[11] = state[7];
    state[7] = temp;
}

static void aes_mixcolumns(uint8_t* state) {
    uint8_t a, b, c, d;
    for(int i = 0; i < 4; i++) {
        a = state[i * 4];
        b = state[i * 4 + 1];
        c = state[i * 4 + 2];
        d = state[i * 4 + 3];
        state[i * 4] = gf_mul2(a) ^ gf_mul2(b) ^ b ^ c ^ d;
        state[i * 4 + 1] = a ^ gf_mul2(b) ^ gf_mul2(c) ^ c ^ d;
        state[i * 4 + 2] = a ^ b ^ gf_mul2(c) ^ gf_mul2(d) ^ d;
        state[i * 4 + 3] = gf_mul2(a) ^ a ^ b ^ c ^ gf_mul2(d);
    }
}

static void aes128_encrypt(const uint8_t* expanded_key, uint8_t* data) {
    uint8_t state[16];
    memcpy(state, data, 16);
    aes_addroundkey(state, &expanded_key[0]);
    for(int round = 1; round < 10; round++) {
        aes_subbytes(state);
        aes_shiftrows(state);
        aes_mixcolumns(state);
        aes_addroundkey(state, &expanded_key[round * 16]);
    }
    aes_subbytes(state);
    aes_shiftrows(state);
    aes_addroundkey(state, &expanded_key[160]);
    memcpy(data, state, 16);
}

static void aes_key_expansion(const uint8_t* key, uint8_t* round_keys) {
    for(int i = 0; i < 16; i++) {
        round_keys[i] = key[i];
    }

    for(int i = 4; i < 44; i++) {
        int prev_word_idx = (i - 1) * 4;
        uint8_t b0 = round_keys[prev_word_idx];
        uint8_t b1 = round_keys[prev_word_idx + 1];
        uint8_t b2 = round_keys[prev_word_idx + 2];
        uint8_t b3 = round_keys[prev_word_idx + 3];

        if((i % 4) == 0) {
            uint8_t new_b0 = aes_sbox[b1] ^ aes_rcon[(i / 4) - 1];
            uint8_t new_b1 = aes_sbox[b2];
            uint8_t new_b2 = aes_sbox[b3];
            uint8_t new_b3 = aes_sbox[b0];
            b0 = new_b0;
            b1 = new_b1;
            b2 = new_b2;
            b3 = new_b3;
        }

        int back_word_idx = (i - 4) * 4;
        b0 ^= round_keys[back_word_idx];
        b1 ^= round_keys[back_word_idx + 1];
        b2 ^= round_keys[back_word_idx + 2];
        b3 ^= round_keys[back_word_idx + 3];

        int curr_word_idx = i * 4;
        round_keys[curr_word_idx] = b0;
        round_keys[curr_word_idx + 1] = b1;
        round_keys[curr_word_idx + 2] = b2;
        round_keys[curr_word_idx + 3] = b3;
    }
}

static void aes128_decrypt(const uint8_t* expanded_key, uint8_t* data) {
    uint8_t state[16];
    memcpy(state, data, 16);

    aes_addroundkey(state, &expanded_key[160]);

    for(int round = 9; round > 0; round--) {
        aes_shiftrows_inv(state);
        aes_subbytes_inv(state);
        aes_addroundkey(state, &expanded_key[round * 16]);
        aes_mixcolumns_inv(state);
    }

    aes_shiftrows_inv(state);
    aes_subbytes_inv(state);
    aes_addroundkey(state, &expanded_key[0]);

    memcpy(data, state, 16);
}

static void get_kia_v6_aes_key(uint8_t* aes_key) {
    uint64_t keystore_a = 0x37CE21F8C9F862A8ULL ^ 0x5448455049524154ULL;
    uint32_t keystore_a_hi = (keystore_a >> 32) & 0xFFFFFFFF;
    uint32_t keystore_a_lo = keystore_a & 0xFFFFFFFF;

    uint32_t uVar15_a = keystore_a_lo ^ KIA_V6_XOR_MASK_LOW;
    uint32_t uVar5_a = KIA_V6_XOR_MASK_HIGH ^ keystore_a_hi;

    uint64_t val64_a = ((uint64_t)uVar5_a << 32) | uVar15_a;
    for(int i = 0; i < 8; i++) {
        aes_key[i] = (val64_a >> (56 - i * 8)) & 0xFF;
    }

    uint64_t keystore_b = 0x3FC629F0C1F06AA0ULL ^ 0x5448455049524154ULL;
    uint32_t keystore_b_hi = (keystore_b >> 32) & 0xFFFFFFFF;
    uint32_t keystore_b_lo = keystore_b & 0xFFFFFFFF;

    uint32_t uVar15_b = keystore_b_lo ^ KIA_V6_XOR_MASK_LOW;
    uint32_t uVar5_b = KIA_V6_XOR_MASK_HIGH ^ keystore_b_hi;

    uint64_t val64_b = ((uint64_t)uVar5_b << 32) | uVar15_b;
    for(int i = 0; i < 8; i++) {
        aes_key[i + 8] = (val64_b >> (56 - i * 8)) & 0xFF;
    }
}

static void kia_v6_encrypt_payload(
    uint8_t fx_field,
    uint32_t serial,
    uint8_t btn,
    uint32_t cnt,
    uint32_t* out_part1_low,
    uint32_t* out_part1_high,
    uint32_t* out_part2_low,
    uint32_t* out_part2_high,
    uint16_t* out_part3) {
    uint8_t plain[16];
    memset(plain, 0, 16);
    plain[0] = fx_field;
    plain[4] = (serial >> 16) & 0xFF;
    plain[5] = (serial >> 8) & 0xFF;
    plain[6] = serial & 0xFF;
    plain[7] = btn & 0x0F;
    plain[8] = (cnt >> 24) & 0xFF;
    plain[9] = (cnt >> 16) & 0xFF;
    plain[10] = (cnt >> 8) & 0xFF;
    plain[11] = cnt & 0xFF;
    plain[12] = aes_sbox[cnt & 0xFF];
    plain[15] = kia_v6_crc8(plain, 15);

    uint8_t aes_key[16];
    get_kia_v6_aes_key(aes_key);
    uint8_t expanded_key[176];
    aes_key_expansion(aes_key, expanded_key);
    aes128_encrypt(expanded_key, plain);

    uint8_t fx_hi = 0x20 | (fx_field >> 4);
    uint8_t fx_lo = fx_field & 0x0F;
    *out_part1_high = ((uint32_t)fx_hi << 24) | ((uint32_t)fx_lo << 16) |
                      ((uint32_t)plain[0] << 8) | plain[1];
    *out_part1_low = ((uint32_t)plain[2] << 24) | ((uint32_t)plain[3] << 16) |
                     ((uint32_t)plain[4] << 8) | plain[5];
    *out_part2_high = ((uint32_t)plain[6] << 24) | ((uint32_t)plain[7] << 16) |
                      ((uint32_t)plain[8] << 8) | plain[9];
    *out_part2_low = ((uint32_t)plain[10] << 24) | ((uint32_t)plain[11] << 16) |
                     ((uint32_t)plain[12] << 8) | plain[13];
    *out_part3 = ((uint16_t)plain[14] << 8) | plain[15];
}

static bool kia_v6_decrypt(SubGhzProtocolDecoderKiaV6* instance) {
    uint8_t encrypted_data[16];

    encrypted_data[0] = (instance->stored_part1_high >> 8) & 0xFF;
    encrypted_data[1] = instance->stored_part1_high & 0xFF;

    encrypted_data[2] = (instance->stored_part1_low >> 24) & 0xFF;
    encrypted_data[3] = (instance->stored_part1_low >> 16) & 0xFF;
    encrypted_data[4] = (instance->stored_part1_low >> 8) & 0xFF;
    encrypted_data[5] = instance->stored_part1_low & 0xFF;

    encrypted_data[6] = (instance->stored_part2_high >> 24) & 0xFF;
    encrypted_data[7] = (instance->stored_part2_high >> 16) & 0xFF;
    encrypted_data[8] = (instance->stored_part2_high >> 8) & 0xFF;
    encrypted_data[9] = instance->stored_part2_high & 0xFF;

    encrypted_data[10] = (instance->stored_part2_low >> 24) & 0xFF;
    encrypted_data[11] = (instance->stored_part2_low >> 16) & 0xFF;
    encrypted_data[12] = (instance->stored_part2_low >> 8) & 0xFF;
    encrypted_data[13] = instance->stored_part2_low & 0xFF;

    encrypted_data[14] = (instance->data_part3 >> 8) & 0xFF;
    encrypted_data[15] = instance->data_part3 & 0xFF;

    uint8_t fx_byte0 = (instance->stored_part1_high >> 24) & 0xFF;
    uint8_t fx_byte1 = (instance->stored_part1_high >> 16) & 0xFF;
    instance->fx_field = ((fx_byte0 & 0xF) << 4) | (fx_byte1 & 0xF);

    uint8_t aes_key[16];
    get_kia_v6_aes_key(aes_key);
    uint8_t expanded_key[176];
    aes_key_expansion(aes_key, expanded_key);
    aes128_decrypt(expanded_key, encrypted_data);

    uint8_t* decrypted = encrypted_data;

    uint8_t calculated_crc = kia_v6_crc8(decrypted, 15);
    uint8_t stored_crc = decrypted[15];

    instance->generic.serial = ((uint32_t)decrypted[4] << 16) | ((uint32_t)decrypted[5] << 8) |
                               decrypted[6];

    instance->generic.btn = decrypted[7];

    instance->generic.cnt = ((uint32_t)decrypted[8] << 24) | ((uint32_t)decrypted[9] << 16) |
                            ((uint32_t)decrypted[10] << 8) | decrypted[11];

    instance->crc1_field = decrypted[12];

    instance->crc2_field = decrypted[15];

    return (calculated_crc ^ stored_crc) < 2;
}

const SubGhzProtocolDecoder subghz_protocol_kia_v6_decoder = {
    .alloc = subghz_protocol_decoder_kia_v6_alloc,
    .free = subghz_protocol_decoder_kia_v6_free,
    .feed = subghz_protocol_decoder_kia_v6_feed,
    .reset = subghz_protocol_decoder_kia_v6_reset,
    .get_hash_data = subghz_protocol_decoder_kia_v6_get_hash_data,
    .serialize = subghz_protocol_decoder_kia_v6_serialize,
    .deserialize = subghz_protocol_decoder_kia_v6_deserialize,
    .get_string = subghz_protocol_decoder_kia_v6_get_string,
};

const SubGhzProtocolEncoder subghz_protocol_kia_v6_encoder = {
    .alloc = subghz_protocol_encoder_kia_v6_alloc,
    .free = subghz_protocol_encoder_kia_v6_free,
    .deserialize = subghz_protocol_encoder_kia_v6_deserialize,
    .stop = subghz_protocol_encoder_kia_v6_stop,
    .yield = subghz_protocol_encoder_kia_v6_yield,
};

const SubGhzProtocol subghz_protocol_kia_v6 = {
    .name = SUBGHZ_PROTOCOL_KIA_V6_NAME,
    .type = SubGhzProtocolTypeDynamic,
    .flag = SubGhzProtocolFlag_315 | SubGhzProtocolFlag_433 | SubGhzProtocolFlag_FM |
            SubGhzProtocolFlag_Decodable |
            SubGhzProtocolFlag_Save | SubGhzProtocolFlag_Load | SubGhzProtocolFlag_Send,
    .decoder = &subghz_protocol_kia_v6_decoder,
    .encoder = &subghz_protocol_kia_v6_encoder,
};

void* subghz_protocol_decoder_kia_v6_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);
    SubGhzProtocolDecoderKiaV6* instance = malloc(sizeof(SubGhzProtocolDecoderKiaV6));
    furi_assert(instance);
    memset(instance, 0, sizeof(SubGhzProtocolDecoderKiaV6));

    instance->base.protocol = &subghz_protocol_kia_v6;
    instance->generic.protocol_name = instance->base.protocol->name;
    return instance;
}

void subghz_protocol_decoder_kia_v6_free(void* context) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV6* instance = context;
    free(instance);
}

void subghz_protocol_decoder_kia_v6_reset(void* context) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV6* instance = context;
    instance->decoder.parser_step = KiaV6DecoderStepReset;
    instance->header_count = 0;
    instance->bit_count = 0;
    instance->data_part1_low = 0;
    instance->data_part1_high = 0;
    manchester_advance(
        instance->manchester_state, ManchesterEventReset, &instance->manchester_state, NULL);
}

void subghz_protocol_decoder_kia_v6_feed(void* context, bool level, uint32_t duration) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV6* instance = context;

    switch(instance->decoder.parser_step) {
    case KiaV6DecoderStepReset:
        if(level == 0) {
            return;
        }
        if(DURATION_DIFF(duration, subghz_protocol_kia_v6_const.te_short) <
           subghz_protocol_kia_v6_const.te_delta) {
            instance->decoder.parser_step = KiaV6DecoderStepWaitFirstHigh;
            instance->decoder.te_last = duration;
            instance->header_count = 0;
            manchester_advance(
                instance->manchester_state,
                ManchesterEventReset,
                &instance->manchester_state,
                NULL);
        }
        return;

    case KiaV6DecoderStepWaitFirstHigh:
        if(level != 0) {
            return;
        }
        uint32_t diff_short = DURATION_DIFF(duration, subghz_protocol_kia_v6_const.te_short);
        uint32_t diff_long = DURATION_DIFF(duration, subghz_protocol_kia_v6_const.te_long);

        uint32_t diff = (diff_long < diff_short) ? diff_long : diff_short;

        if(diff_long < subghz_protocol_kia_v6_const.te_delta && diff_long < diff_short) {
            if(instance->header_count >= 0x259) {
                instance->header_count = 0;
                instance->decoder.te_last = duration;
                instance->decoder.parser_step = KiaV6DecoderStepWaitLongHigh;
                return;
            }
        }

        if(diff >= subghz_protocol_kia_v6_const.te_delta) {
            instance->decoder.parser_step = KiaV6DecoderStepReset;
            return;
        }

        if(DURATION_DIFF(instance->decoder.te_last, subghz_protocol_kia_v6_const.te_short) <
           subghz_protocol_kia_v6_const.te_delta) {
            instance->decoder.te_last = duration;
            instance->header_count++;
            return;
        } else {
            instance->decoder.parser_step = KiaV6DecoderStepReset;
            return;
        }

    case KiaV6DecoderStepWaitLongHigh:
        if(level == 0) {
            instance->decoder.parser_step = KiaV6DecoderStepReset;
            return;
        }
        uint32_t diff_long_check = DURATION_DIFF(duration, subghz_protocol_kia_v6_const.te_long);
        uint32_t diff_short_check = DURATION_DIFF(duration, subghz_protocol_kia_v6_const.te_short);

        if(diff_long_check >= subghz_protocol_kia_v6_const.te_delta) {
            if(diff_short_check >= subghz_protocol_kia_v6_const.te_delta) {
                instance->decoder.parser_step = KiaV6DecoderStepReset;
                return;
            }
        }

        if(DURATION_DIFF(instance->decoder.te_last, subghz_protocol_kia_v6_const.te_long) >=
           subghz_protocol_kia_v6_const.te_delta) {
            instance->decoder.parser_step = KiaV6DecoderStepReset;
            return;
        }
        instance->decoder.decode_data = 0;
        instance->decoder.decode_count_bit = 0;

        subghz_protocol_blocks_add_bit(&instance->decoder, 1);
        subghz_protocol_blocks_add_bit(&instance->decoder, 1);
        subghz_protocol_blocks_add_bit(&instance->decoder, 0);
        subghz_protocol_blocks_add_bit(&instance->decoder, 1);

        instance->data_part1_low = (uint32_t)(instance->decoder.decode_data & 0xFFFFFFFF);
        instance->data_part1_high =
            (uint32_t)((instance->decoder.decode_data >> 32) & 0xFFFFFFFF);
        instance->bit_count = instance->decoder.decode_count_bit;

        instance->decoder.parser_step = KiaV6DecoderStepData;
        return;

    case KiaV6DecoderStepData: {
        ManchesterEvent event;
        bool data_bit;

        if(DURATION_DIFF(duration, subghz_protocol_kia_v6_const.te_short) <
           subghz_protocol_kia_v6_const.te_delta) {
            event = (level & 0x7F) << 1;
        } else if(
            DURATION_DIFF(duration, subghz_protocol_kia_v6_const.te_long) <
            subghz_protocol_kia_v6_const.te_delta) {
            event = level ? ManchesterEventLongHigh : ManchesterEventLongLow;
        } else {
            instance->decoder.parser_step = KiaV6DecoderStepReset;
            return;
        }

        if(manchester_advance(
               instance->manchester_state, event, &instance->manchester_state, &data_bit)) {
            uint32_t uVar4 = instance->data_part1_low;
            uint32_t uVar5 = (uVar4 << 1) | (data_bit ? 1 : 0);
            uint32_t carry = (uVar4 >> 31) & 1;
            uVar4 = (instance->data_part1_high << 1) | carry;
            instance->data_part1_low = uVar5;
            instance->data_part1_high = uVar4;
            instance->decoder.decode_data = ((uint64_t)uVar4 << 32) | uVar5;
            instance->bit_count++;

            if(instance->bit_count == 0x40) {
                instance->stored_part1_low = ~uVar5;
                instance->stored_part1_high = ~uVar4;
                instance->data_part1_low = 0;
                instance->data_part1_high = 0;
            } else if(instance->bit_count == 0x80) {
                instance->stored_part2_low = ~uVar5;
                instance->stored_part2_high = ~uVar4;
                instance->data_part1_low = 0;
                instance->data_part1_high = 0;
            }
        }

        instance->decoder.te_last = duration;

        if(instance->bit_count != subghz_protocol_kia_v6_const.min_count_bit_for_found) {
            return;
        }

        instance->generic.data_count_bit = subghz_protocol_kia_v6_const.min_count_bit_for_found;
        instance->data_part3 = ~((uint16_t)instance->data_part1_low);
        instance->generic.data =
            ((uint64_t)instance->stored_part1_high << 32) | instance->stored_part1_low;

        kia_v6_decrypt(instance);

        if(instance->base.callback) {
            instance->base.callback(&instance->base, instance->base.context);
        }

        instance->data_part1_low = 0;
        instance->data_part1_high = 0;
        instance->bit_count = 0;
        instance->decoder.parser_step = KiaV6DecoderStepReset;
        return;
    }

    default:
        return;
    }
}

uint8_t subghz_protocol_decoder_kia_v6_get_hash_data(void* context) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV6* instance = context;
    uint8_t hash = 0;
    hash ^= (instance->stored_part1_low >> 24) & 0xFF;
    hash ^= (instance->stored_part1_low >> 16) & 0xFF;
    hash ^= (instance->stored_part1_low >> 8) & 0xFF;
    hash ^= instance->stored_part1_low & 0xFF;
    hash ^= (instance->stored_part1_high >> 24) & 0xFF;
    hash ^= (instance->stored_part1_high >> 16) & 0xFF;
    hash ^= (instance->stored_part1_high >> 8) & 0xFF;
    hash ^= instance->stored_part1_high & 0xFF;
    return hash;
}

SubGhzProtocolStatus subghz_protocol_decoder_kia_v6_serialize(
    void* context,
    FlipperFormat* flipper_format,
    SubGhzRadioPreset* preset) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV6* instance = context;

    SubGhzProtocolStatus ret =
        subghz_block_generic_serialize(&instance->generic, flipper_format, preset);

    // [PROTOPIRATE_PORT] Persist Serial/Btn/Cnt (as ProtoPirate's pp_serialize_fields
    // does). The car-emulate scene reads "Cnt" to seed original_counter; without it the
    // rolling counter would restart from 0 and desync from the vehicle.
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t serial_tmp = instance->generic.serial;
        if(!flipper_format_write_uint32(flipper_format, "Serial", &serial_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t btn_tmp = instance->generic.btn;
        if(!flipper_format_write_uint32(flipper_format, "Btn", &btn_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t cnt_tmp = instance->generic.cnt;
        if(!flipper_format_write_uint32(flipper_format, "Cnt", &cnt_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t key2_low = instance->stored_part2_low;
        if(!flipper_format_write_uint32(flipper_format, "Key_2", &key2_low, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t key2_high = instance->stored_part2_high;
        if(!flipper_format_write_uint32(flipper_format, "Key_3", &key2_high, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t key3 = instance->data_part3;
        if(!flipper_format_write_uint32(flipper_format, "Key_4", &key3, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t fx = instance->fx_field;
        if(!flipper_format_write_uint32(flipper_format, "Fx", &fx, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    return ret;
}

SubGhzProtocolStatus
    subghz_protocol_decoder_kia_v6_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV6* instance = context;

    SubGhzProtocolStatus ret =
        subghz_block_generic_deserialize(&instance->generic, flipper_format);
    if(ret == SubGhzProtocolStatusOk) {
        if(instance->generic.data_count_bit <
           subghz_protocol_kia_v6_const.min_count_bit_for_found) {
            ret = SubGhzProtocolStatusErrorParserBitCount;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t temp;
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Key_2", &temp, 1)) {
            instance->stored_part2_low = temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Key_3", &temp, 1)) {
            instance->stored_part2_high = temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Key_4", &temp, 1)) {
            instance->data_part3 = (uint16_t)temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Fx", &temp, 1)) {
            instance->fx_field = (uint8_t)temp;
        }
        instance->stored_part1_high = (uint32_t)((instance->generic.data >> 32) & 0xFFFFFFFF);
        instance->stored_part1_low = (uint32_t)(instance->generic.data & 0xFFFFFFFF);
        kia_v6_decrypt(instance);
    }
    return ret;
}

void subghz_protocol_decoder_kia_v6_get_string(void* context, FuriString* output) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV6* instance = context;

    kia_v6_decrypt(instance);

    uint32_t key1_hi = instance->stored_part1_high;
    uint32_t key1_lo = instance->stored_part1_low;
    uint32_t serial_6 = instance->generic.serial & 0xFFFFFF;

    // [BUGFIX UI] Re-derive the displayed button from the current D-pad
    // selection so the transmitter UI reflects subghz_custom_btn_get() (like
    // psa.c/star_line.c), mirroring the encoder remap (see encoder deserialize):
    // Up=Lock(0x1), Down=Unlock(0x2), Left=Trunk(0x3), Right=Panic(0x4),
    // OK=captured. kia_v6_decrypt() just reset generic.btn to the captured value,
    // so apply the remap here. CRC shown is the captured frame's; the encoder
    // re-encrypts and recomputes CRC for the transmitted button.
    subghz_custom_btn_set_max(4);
    uint8_t display_btn = (uint8_t)(instance->generic.btn & 0x0FU);
    switch(subghz_custom_btn_get()) {
    case SUBGHZ_CUSTOM_BTN_UP:
        display_btn = 0x01U; // Lock
        break;
    case SUBGHZ_CUSTOM_BTN_DOWN:
        display_btn = 0x02U; // Unlock
        break;
    case SUBGHZ_CUSTOM_BTN_LEFT:
        display_btn = 0x03U; // Trunk
        break;
    case SUBGHZ_CUSTOM_BTN_RIGHT:
        display_btn = 0x04U; // Panic
        break;
    case SUBGHZ_CUSTOM_BTN_OK:
    default:
        break;
    }

    const char* btn_name;
    switch(display_btn & 0x0F) {
    case 0x01:
        btn_name = "Lock";
        break;
    case 0x02:
        btn_name = "Unlock";
        break;
    case 0x03:
        btn_name = "Trunk";
        break;
    case 0x04:
        btn_name = "Panic";
        break;
    default:
        btn_name = "Unknown";
        break;
    }

    furi_string_printf(
        output,
        "%s %dbit\r\n"
        "Key:0x%08lX%08lX\r\n"
        "SN:0x%06lX Btn:[%s]\r\n"
        "CRC:%02X-%02X Cnt:%08lX\r\n",
        instance->generic.protocol_name,
        instance->generic.data_count_bit,
        key1_hi,
        key1_lo,
        serial_6,
        btn_name,
        instance->crc1_field,
        instance->crc2_field,
        instance->generic.cnt);
}

static inline void kia_v6_encode_manchester_bit(
    LevelDuration* upload,
    size_t* index,
    bool bit,
    uint32_t te) {
    if(bit) {
        upload[(*index)++] = level_duration_make(false, te);
        upload[(*index)++] = level_duration_make(true, te);
    } else {
        upload[(*index)++] = level_duration_make(true, te);
        upload[(*index)++] = level_duration_make(false, te);
    }
}

static void kia_v6_encode_message(
    LevelDuration* upload,
    size_t* index,
    int preamble_pairs,
    uint32_t p1_lo,
    uint32_t p1_hi,
    uint32_t p2_lo,
    uint32_t p2_hi,
    uint16_t p3) {
    const uint32_t te_short = subghz_protocol_kia_v6_const.te_short;

    for(int i = 0; i < preamble_pairs; i++) {
        upload[(*index)++] = level_duration_make(true, te_short);
        upload[(*index)++] = level_duration_make(false, te_short);
    }
    upload[(*index)++] = level_duration_make(false, te_short);
    upload[(*index)++] = level_duration_make(true, subghz_protocol_kia_v6_const.te_long);
    upload[(*index)++] = level_duration_make(false, te_short);

    for(int b = 60; b >= 0; b--) {
        uint32_t word = (b >= 32) ? p1_hi : p1_lo;
        int shift = (b >= 32) ? (b - 32) : b;
        kia_v6_encode_manchester_bit(upload, index, ((~word) >> shift) & 1, te_short);
    }
    for(int b = 63; b >= 0; b--) {
        uint32_t word = (b >= 32) ? p2_hi : p2_lo;
        int shift = (b >= 32) ? (b - 32) : b;
        kia_v6_encode_manchester_bit(upload, index, ((~word) >> shift) & 1, te_short);
    }
    for(int b = 15; b >= 0; b--) {
        kia_v6_encode_manchester_bit(upload, index, ((~p3) >> b) & 1, te_short);
    }
}

static void kia_v6_encoder_build_upload(SubGhzProtocolEncoderKiaV6* instance) {
    furi_assert(instance);

    kia_v6_encrypt_payload(
        instance->fx_field,
        instance->generic.serial,
        instance->generic.btn & 0x0F,
        instance->generic.cnt,
        &instance->stored_part1_low,
        &instance->stored_part1_high,
        &instance->stored_part2_low,
        &instance->stored_part2_high,
        &instance->data_part3);

    uint32_t p1_lo = instance->stored_part1_low;
    uint32_t p1_hi = instance->stored_part1_high;
    uint32_t p2_lo = instance->stored_part2_low;
    uint32_t p2_hi = instance->stored_part2_high;
    uint16_t p3 = instance->data_part3;

    size_t index = 0;
    kia_v6_encode_message(
        instance->encoder.upload, &index, KIA_V6_PREAMBLE_PAIRS_1, p1_lo, p1_hi, p2_lo, p2_hi, p3);
    instance->encoder.upload[index++] =
        level_duration_make(false, subghz_protocol_kia_v6_const.te_long);
    kia_v6_encode_message(
        instance->encoder.upload, &index, KIA_V6_PREAMBLE_PAIRS_2, p1_lo, p1_hi, p2_lo, p2_hi, p3);
    instance->encoder.upload[index++] =
        level_duration_make(false, subghz_protocol_kia_v6_const.te_long);

    instance->encoder.size_upload = index;
    instance->encoder.front = 0;
}

void* subghz_protocol_encoder_kia_v6_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);
    SubGhzProtocolEncoderKiaV6* instance = malloc(sizeof(SubGhzProtocolEncoderKiaV6));
    if(!instance) return NULL;
    memset(instance, 0, sizeof(SubGhzProtocolEncoderKiaV6));
    instance->base.protocol = &subghz_protocol_kia_v6;
    instance->generic.protocol_name = instance->base.protocol->name;
    instance->encoder.size_upload = KIA_V6_UPLOAD_SIZE;
    instance->encoder.upload = malloc(instance->encoder.size_upload * sizeof(LevelDuration));
    if(!instance->encoder.upload) {
        free(instance);
        return NULL;
    }
    instance->encoder.repeat = 3;
    instance->encoder.front = 0;
    instance->encoder.is_running = false;
    return instance;
}

void subghz_protocol_encoder_kia_v6_free(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV6* instance = context;
    if(instance->encoder.upload) {
        free(instance->encoder.upload);
    }
    free(instance);
}

SubGhzProtocolStatus
    subghz_protocol_encoder_kia_v6_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV6* instance = context;
    SubGhzProtocolStatus ret = SubGhzProtocolStatusError;

    instance->encoder.is_running = false;
    instance->encoder.front = 0;
    instance->encoder.repeat = 3;

    do {
        ret = subghz_block_generic_deserialize(&instance->generic, flipper_format);
        if(ret != SubGhzProtocolStatusOk) break;
        if(instance->generic.data_count_bit <
           subghz_protocol_kia_v6_const.min_count_bit_for_found) {
            ret = SubGhzProtocolStatusErrorParserBitCount;
            break;
        }

        uint32_t temp;
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Key_2", &temp, 1)) {
            instance->stored_part2_low = temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Key_3", &temp, 1)) {
            instance->stored_part2_high = temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Key_4", &temp, 1)) {
            instance->data_part3 = (uint16_t)temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Fx", &temp, 1)) {
            instance->fx_field = (uint8_t)temp;
        }

        instance->stored_part1_high = (uint32_t)((instance->generic.data >> 32) & 0xFFFFFFFF);
        instance->stored_part1_low = (uint32_t)(instance->generic.data & 0xFFFFFFFF);

        SubGhzProtocolDecoderKiaV6 dec = {0};
        dec.stored_part1_low = instance->stored_part1_low;
        dec.stored_part1_high = instance->stored_part1_high;
        dec.stored_part2_low = instance->stored_part2_low;
        dec.stored_part2_high = instance->stored_part2_high;
        dec.data_part3 = instance->data_part3;

        kia_v6_decrypt(&dec);

        instance->generic.serial = dec.generic.serial;
        instance->generic.btn = dec.generic.btn;
        instance->generic.cnt = dec.generic.cnt;
        instance->generic.data_count_bit = subghz_protocol_kia_v6_const.min_count_bit_for_found;
        instance->fx_field = dec.fx_field;

        // [PROTOPIRATE_PORT] Honor the app-supplied Serial/Btn/Cnt overrides so the
        // rolling counter actually advances on each TX. The car-emulate scene writes an
        // incremented "Cnt" into the flipper_format before re-invoking this deserialize.
        // Without reading it back here, cnt is re-derived from the AES-decrypted stored
        // key and the frame is a byte-identical replay. kia_v6_encoder_build_upload()
        // re-runs AES with the new cnt (and recomputes the embedded CRC), so the emitted
        // frame is a valid forward-encoded rolling code.
        {
            uint32_t ser_u32 = 0;
            uint32_t btn_u32 = 0;
            uint32_t cnt_u32 = 0;
            flipper_format_rewind(flipper_format);
            if(flipper_format_read_uint32(flipper_format, "Serial", &ser_u32, 1)) {
                instance->generic.serial = ser_u32;
            }
            flipper_format_rewind(flipper_format);
            if(flipper_format_read_uint32(flipper_format, "Btn", &btn_u32, 1)) {
                instance->generic.btn = (uint8_t)btn_u32;
            }
            flipper_format_rewind(flipper_format);
            if(flipper_format_read_uint32(flipper_format, "Cnt", &cnt_u32, 1)) {
                instance->generic.cnt = cnt_u32;
            }
        }

        // [PROTOPIRATE_PORT] custom_btn support
        // Kia V6 codes (see get_string switch): Lock=0x01, Unlock=0x02,
        // Trunk=0x03, Panic=0x04. build_upload re-encrypts using
        // instance->generic.btn, so remap it here before that call.
        {
            const uint8_t original_btn = (uint8_t)(instance->generic.btn & 0x0FU);
            if(subghz_custom_btn_get_original() == 0) {
                subghz_custom_btn_set_original(original_btn);
            }
            subghz_custom_btn_set_max(4);
            uint8_t custom_btn_id = subghz_custom_btn_get();
            switch(custom_btn_id) {
            case SUBGHZ_CUSTOM_BTN_UP:    instance->generic.btn = 0x01U;         break; // Lock
            case SUBGHZ_CUSTOM_BTN_OK:    instance->generic.btn = original_btn;  break;
            case SUBGHZ_CUSTOM_BTN_DOWN:  instance->generic.btn = 0x02U;         break; // Unlock
            case SUBGHZ_CUSTOM_BTN_LEFT:  instance->generic.btn = 0x03U;         break; // Trunk
            case SUBGHZ_CUSTOM_BTN_RIGHT: instance->generic.btn = 0x04U;         break; // Panic
            default:                      instance->generic.btn = original_btn;  break;
            }
            instance->generic.btn &= 0x0FU;
        }

        // [ROLLING_CNT] Forward-encode the NEXT counter (like VAG/PSA) so the
        // transmitter UI shows an incrementing counter on each OK/D-pad press.
        // kia_v6_encoder_build_upload() re-runs AES with this cnt and refreshes the
        // stored_part fields; we persist them below so the decoder re-derives the
        // advanced counter on the UI refresh.
        {
            uint32_t mult = furi_hal_subghz_get_rolling_counter_mult();
            if(mult == 0U) mult = 1U;
            instance->generic.cnt = instance->generic.cnt + mult;
        }

        kia_v6_encoder_build_upload(instance);

        // [ROLLING_CNT] Persist the re-encrypted AES frame (Key + Key_2/3/4) and the
        // advanced Cnt so the UI refresh (decoder AES-decrypts the Key) shows the
        // incremented counter and the next TX continues from here.
        {
            instance->generic.data = ((uint64_t)instance->stored_part1_high << 32) |
                                     instance->stored_part1_low;
            uint8_t key_data[8];
            for(int i = 0; i < 8; i++) {
                key_data[i] = (uint8_t)((instance->generic.data >> (56 - 8 * i)) & 0xFF);
            }
            flipper_format_rewind(flipper_format);
            flipper_format_update_hex(flipper_format, "Key", key_data, 8);

            uint32_t tmp = instance->stored_part2_low;
            flipper_format_rewind(flipper_format);
            flipper_format_insert_or_update_uint32(flipper_format, "Key_2", &tmp, 1);
            tmp = instance->stored_part2_high;
            flipper_format_rewind(flipper_format);
            flipper_format_insert_or_update_uint32(flipper_format, "Key_3", &tmp, 1);
            tmp = instance->data_part3;
            flipper_format_rewind(flipper_format);
            flipper_format_insert_or_update_uint32(flipper_format, "Key_4", &tmp, 1);

            uint32_t cnt_store = instance->generic.cnt;
            flipper_format_rewind(flipper_format);
            flipper_format_insert_or_update_uint32(flipper_format, "Cnt", &cnt_store, 1);
        }

        instance->encoder.is_running = true;
        ret = SubGhzProtocolStatusOk;
    } while(false);

    return ret;
}

void subghz_protocol_encoder_kia_v6_stop(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV6* instance = context;
    instance->encoder.is_running = false;
}

LevelDuration subghz_protocol_encoder_kia_v6_yield(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV6* instance = context;

    if(!instance->encoder.is_running || instance->encoder.repeat <= 0) {
        instance->encoder.is_running = false;
        return level_duration_reset();
    }

    LevelDuration ret = instance->encoder.upload[instance->encoder.front];
    instance->encoder.front++;
    if(instance->encoder.front >= instance->encoder.size_upload) {
        // Endless/breakless TX: while OK is held (endless_tx set by the transmit
        // scene) do not consume repeats, so the signal loops until release.
        if(!subghz_block_generic_global.endless_tx) instance->encoder.repeat--;
        instance->encoder.front = 0;
    }
    return ret;
}
