#include "kia_v3_v4.h"
#include "../blocks/const.h"
#include "../blocks/decoder.h"
#include "../blocks/encoder.h"
#include "../blocks/generic.h"
#include "../blocks/math.h"
#include "../blocks/custom_btn_i.h"
#include "keeloq_common.h"

#define TAG "SubGhzProtocolKiaV3V4"

#define KIA_MF_KEY 0xA8F5DFFC8DAA5CDBULL

static const char* kia_version_names[] = {"Kia V4", "Kia V3"};

#define KIA_V3_V4_PREAMBLE_PAIRS  12U
#define KIA_V3_V4_BIT_COUNT       64U
#define KIA_V3_V4_CRC_BIT_COUNT   4U
#define KIA_V3_V4_CRC_SWEEP_COUNT 16U
#define KIA_V3_V4_SYNC_DURATION   1200U
#define KIA_V3_V4_END_MARKER_US   800U
#define KIA_V3_V4_DEFAULT_REPEAT  KIA_V3_V4_CRC_SWEEP_COUNT

#define KIA_V3_V4_DATA_OFFSET   ((KIA_V3_V4_PREAMBLE_PAIRS * 2U) + 2U)
#define KIA_V3_V4_CRC_OFFSET    (KIA_V3_V4_DATA_OFFSET + (KIA_V3_V4_BIT_COUNT * 2U))
#define KIA_V3_V4_END_OFFSET    (KIA_V3_V4_CRC_OFFSET + (KIA_V3_V4_CRC_BIT_COUNT * 2U))
#define KIA_V3_V4_BURST_ENTRIES (KIA_V3_V4_END_OFFSET + 2U)

#define KIA_V3_V4_UPLOAD_CAPACITY KIA_V3_V4_BURST_ENTRIES

static const SubGhzBlockConst subghz_protocol_kia_v3_v4_const = {
    .te_short = 400,
    .te_long = 800,
    .te_delta = 150,
    .min_count_bit_for_found = 68,
};

struct SubGhzProtocolDecoderKiaV3V4 {
    SubGhzProtocolDecoderBase base;
    SubGhzBlockDecoder decoder;
    SubGhzBlockGeneric generic;
    uint16_t header_count;

    uint8_t raw_bits[32];
    uint16_t raw_bit_count;
    bool is_v3_sync;

    uint32_t encrypted;
    uint32_t decrypted;
    uint8_t crc;
    uint8_t version;
};

struct SubGhzProtocolEncoderKiaV3V4 {
    SubGhzProtocolEncoderBase base;
    SubGhzProtocolBlockEncoder encoder;
    SubGhzBlockGeneric generic;

    uint32_t serial;
    uint8_t btn;
    uint16_t cnt;
    uint8_t version;

    uint32_t encrypted;
    uint32_t decrypted;

    uint8_t crc_iter;
    uint8_t bursts_sent;
};

typedef enum {
    KiaV3V4DecoderStepReset = 0,
    KiaV3V4DecoderStepCheckPreamble,
    KiaV3V4DecoderStepCollectRawBits,
} KiaV3V4DecoderStep;

static uint8_t kia_v3_v4_reverse8(uint8_t byte) {
    byte = (byte & 0xF0) >> 4 | (byte & 0x0F) << 4;
    byte = (byte & 0xCC) >> 2 | (byte & 0x33) << 2;
    byte = (byte & 0xAA) >> 1 | (byte & 0x55) << 1;
    return byte;
}

static void kia_v3_v4_add_raw_bit(SubGhzProtocolDecoderKiaV3V4* instance, bool bit) {
    if(instance->raw_bit_count < 256) {
        uint16_t byte_idx = instance->raw_bit_count / 8;
        uint8_t bit_idx = 7 - (instance->raw_bit_count % 8);
        if(bit) {
            instance->raw_bits[byte_idx] |= (1 << bit_idx);
        } else {
            instance->raw_bits[byte_idx] &= ~(1 << bit_idx);
        }
        instance->raw_bit_count++;
    }
}

static inline void kia_v3_v4_emit_bit_pwm(LevelDuration* upload, size_t* idx, bool bit, bool v4) {
    const uint32_t te_short = subghz_protocol_kia_v3_v4_const.te_short;
    const uint32_t te_long = subghz_protocol_kia_v3_v4_const.te_long;
    const uint32_t first_us = bit ? te_short : te_long;
    const uint32_t second_us = bit ? te_long : te_short;

    if(v4) {
        upload[(*idx)++] = level_duration_make(false, (int32_t)first_us);
        upload[(*idx)++] = level_duration_make(true, (int32_t)second_us);
    } else {
        upload[(*idx)++] = level_duration_make(true, (int32_t)first_us);
        upload[(*idx)++] = level_duration_make(false, (int32_t)second_us);
    }
}

static uint64_t kia_v3_v4_build_tx_bitstream(SubGhzProtocolEncoderKiaV3V4* instance) {
    const uint32_t serial_btn = (instance->serial & 0x0FFFFFFFU) |
                                ((uint32_t)(instance->btn & 0x0FU) << 28);
    const uint64_t key = ((uint64_t)serial_btn << 32) | (uint64_t)instance->encrypted;
    return subghz_protocol_blocks_reverse_key(key, 64);
}

static bool kia_v3_v4_process_buffer(SubGhzProtocolDecoderKiaV3V4* instance) {
    if(instance->raw_bit_count < 68) {
        return false;
    }

    uint8_t* b = instance->raw_bits;

    if(instance->is_v3_sync) {
        uint16_t num_bytes = (instance->raw_bit_count + 7) / 8;
        for(uint16_t i = 0; i < num_bytes; i++) {
            b[i] = ~b[i];
        }
    }

    uint8_t crc = (b[8] >> 4) & 0x0F;

    uint32_t encrypted =
        ((uint32_t)kia_v3_v4_reverse8(b[3]) << 24) | ((uint32_t)kia_v3_v4_reverse8(b[2]) << 16) |
        ((uint32_t)kia_v3_v4_reverse8(b[1]) << 8) | (uint32_t)kia_v3_v4_reverse8(b[0]);

    uint32_t serial = ((uint32_t)kia_v3_v4_reverse8(b[7] & 0xF0) << 24) |
                      ((uint32_t)kia_v3_v4_reverse8(b[6]) << 16) |
                      ((uint32_t)kia_v3_v4_reverse8(b[5]) << 8) | (uint32_t)kia_v3_v4_reverse8(b[4]);

    uint8_t btn = (kia_v3_v4_reverse8(b[7]) & 0xF0) >> 4;
    uint8_t our_serial_lsb = serial & 0xFF;

    uint32_t decrypted = subghz_protocol_keeloq_common_decrypt(encrypted, KIA_MF_KEY);
    uint8_t dec_btn = (decrypted >> 28) & 0x0F;
    uint8_t dec_serial_lsb = (decrypted >> 16) & 0xFF;

    if(dec_btn != btn || dec_serial_lsb != our_serial_lsb) {
        return false;
    }

    instance->encrypted = encrypted;
    instance->decrypted = decrypted;
    instance->crc = crc;
    instance->generic.serial = serial;
    instance->generic.btn = btn;
    instance->generic.cnt = decrypted & 0xFFFF;
    instance->version = instance->is_v3_sync ? 1 : 0;

    uint64_t key_data = ((uint64_t)b[0] << 56) | ((uint64_t)b[1] << 48) | ((uint64_t)b[2] << 40) |
                        ((uint64_t)b[3] << 32) | ((uint64_t)b[4] << 24) | ((uint64_t)b[5] << 16) |
                        ((uint64_t)b[6] << 8) | (uint64_t)b[7];
    instance->generic.data = key_data;
    instance->generic.data_count_bit = 68;

    return true;
}

const SubGhzProtocolDecoder subghz_protocol_kia_v3_v4_decoder = {
    .alloc = subghz_protocol_decoder_kia_v3_v4_alloc,
    .free = subghz_protocol_decoder_kia_v3_v4_free,
    .feed = subghz_protocol_decoder_kia_v3_v4_feed,
    .reset = subghz_protocol_decoder_kia_v3_v4_reset,
    .get_hash_data = subghz_protocol_decoder_kia_v3_v4_get_hash_data,
    .serialize = subghz_protocol_decoder_kia_v3_v4_serialize,
    .deserialize = subghz_protocol_decoder_kia_v3_v4_deserialize,
    .get_string = subghz_protocol_decoder_kia_v3_v4_get_string,
};

const SubGhzProtocolEncoder subghz_protocol_kia_v3_v4_encoder = {
    .alloc = subghz_protocol_encoder_kia_v3_v4_alloc,
    .free = subghz_protocol_encoder_kia_v3_v4_free,
    .deserialize = subghz_protocol_encoder_kia_v3_v4_deserialize,
    .stop = subghz_protocol_encoder_kia_v3_v4_stop,
    .yield = subghz_protocol_encoder_kia_v3_v4_yield,
};

const SubGhzProtocol subghz_protocol_kia_v3_v4 = {
    .name = SUBGHZ_PROTOCOL_KIA_V3_V4_NAME,
    .type = SubGhzProtocolTypeDynamic,
    .flag = SubGhzProtocolFlag_315 | SubGhzProtocolFlag_433 | SubGhzProtocolFlag_FM |
            SubGhzProtocolFlag_Decodable | SubGhzProtocolFlag_Load | SubGhzProtocolFlag_Save |
            SubGhzProtocolFlag_Send,
    .decoder = &subghz_protocol_kia_v3_v4_decoder,
    .encoder = &subghz_protocol_kia_v3_v4_encoder,
};

// ============================================================================
// ENCODER IMPLEMENTATION
// ============================================================================

void* subghz_protocol_encoder_kia_v3_v4_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);

    SubGhzProtocolEncoderKiaV3V4* instance = malloc(sizeof(SubGhzProtocolEncoderKiaV3V4));
    furi_check(instance);

    instance->base.protocol = &subghz_protocol_kia_v3_v4;
    instance->generic.protocol_name = instance->base.protocol->name;

    instance->serial = 0;
    instance->btn = 0;
    instance->cnt = 0;
    instance->version = 0;
    instance->crc_iter = 0;
    instance->bursts_sent = 0;

    instance->encoder.size_upload = KIA_V3_V4_UPLOAD_CAPACITY;
    instance->encoder.upload = malloc(instance->encoder.size_upload * sizeof(LevelDuration));
    furi_check(instance->encoder.upload);
    instance->encoder.repeat = (int32_t)KIA_V3_V4_DEFAULT_REPEAT;
    instance->encoder.front = 0;
    instance->encoder.is_running = false;

    return instance;
}

void subghz_protocol_encoder_kia_v3_v4_free(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV3V4* instance = context;
    if(instance->encoder.upload) {
        free(instance->encoder.upload);
    }
    free(instance);
}

static void subghz_protocol_encoder_kia_v3_v4_build_packet(
    SubGhzProtocolEncoderKiaV3V4* instance,
    uint8_t* raw_bytes) {
    uint32_t plaintext = (uint32_t)(instance->cnt & 0xFFFFU) |
                         ((uint32_t)(instance->serial & 0x3FFU) << 16) |
                         ((uint32_t)(instance->btn & 0x0FU) << 28);

    instance->decrypted = plaintext;

    uint32_t encrypted = subghz_protocol_keeloq_common_encrypt(plaintext, KIA_MF_KEY);
    instance->encrypted = encrypted;

    raw_bytes[0] = kia_v3_v4_reverse8((encrypted >> 0) & 0xFF);
    raw_bytes[1] = kia_v3_v4_reverse8((encrypted >> 8) & 0xFF);
    raw_bytes[2] = kia_v3_v4_reverse8((encrypted >> 16) & 0xFF);
    raw_bytes[3] = kia_v3_v4_reverse8((encrypted >> 24) & 0xFF);

    uint32_t serial_btn = (instance->serial & 0x0FFFFFFFU) |
                          ((uint32_t)(instance->btn & 0x0F) << 28);
    raw_bytes[4] = kia_v3_v4_reverse8((serial_btn >> 0) & 0xFF);
    raw_bytes[5] = kia_v3_v4_reverse8((serial_btn >> 8) & 0xFF);
    raw_bytes[6] = kia_v3_v4_reverse8((serial_btn >> 16) & 0xFF);
    raw_bytes[7] = kia_v3_v4_reverse8((serial_btn >> 24) & 0xFF);

    instance->generic.data = ((uint64_t)raw_bytes[0] << 56) | ((uint64_t)raw_bytes[1] << 48) |
                             ((uint64_t)raw_bytes[2] << 40) | ((uint64_t)raw_bytes[3] << 32) |
                             ((uint64_t)raw_bytes[4] << 24) | ((uint64_t)raw_bytes[5] << 16) |
                             ((uint64_t)raw_bytes[6] << 8) | (uint64_t)raw_bytes[7];
    instance->generic.data_count_bit = 68;
}

static void subghz_protocol_encoder_kia_v3_v4_patch_crc(SubGhzProtocolEncoderKiaV3V4* instance) {
    if(!instance || !instance->encoder.upload) return;
    const bool v4 = (instance->version == 0);
    const uint8_t crc = instance->crc_iter & 0x0FU;
    size_t idx = KIA_V3_V4_CRC_OFFSET;
    for(int b = 3; b >= 0; b--) {
        const bool bit = (crc >> b) & 1U;
        kia_v3_v4_emit_bit_pwm(instance->encoder.upload, &idx, bit, v4);
    }
}

static void subghz_protocol_encoder_kia_v3_v4_get_upload(SubGhzProtocolEncoderKiaV3V4* instance) {
    furi_assert(instance);

    uint8_t raw_bytes[8];
    subghz_protocol_encoder_kia_v3_v4_build_packet(instance, raw_bytes);

    const bool v4 = (instance->version == 0);
    const uint64_t tx_key = kia_v3_v4_build_tx_bitstream(instance);

    size_t idx = 0;
    LevelDuration* upload = instance->encoder.upload;
    const uint32_t te_short = subghz_protocol_kia_v3_v4_const.te_short;

    for(uint32_t i = 0; i < KIA_V3_V4_PREAMBLE_PAIRS; i++) {
        if(v4) {
            upload[idx++] = level_duration_make(false, (int32_t)te_short);
            upload[idx++] = level_duration_make(true, (int32_t)te_short);
        } else {
            upload[idx++] = level_duration_make(true, (int32_t)te_short);
            upload[idx++] = level_duration_make(false, (int32_t)te_short);
        }
    }

    if(v4) {
        upload[idx++] = level_duration_make(false, (int32_t)te_short);
        upload[idx++] = level_duration_make(true, (int32_t)KIA_V3_V4_SYNC_DURATION);
    } else {
        upload[idx++] = level_duration_make(true, (int32_t)te_short);
        upload[idx++] = level_duration_make(false, (int32_t)KIA_V3_V4_SYNC_DURATION);
    }

    for(int i = 63; i >= 0; i--) {
        const bool bit = (tx_key >> i) & 1ULL;
        kia_v3_v4_emit_bit_pwm(upload, &idx, bit, v4);
    }

    const uint8_t crc = instance->crc_iter & 0x0FU;
    for(int b = 3; b >= 0; b--) {
        const bool bit = (crc >> b) & 1U;
        kia_v3_v4_emit_bit_pwm(upload, &idx, bit, v4);
    }

    if(v4) {
        upload[idx++] = level_duration_make(false, (int32_t)KIA_V3_V4_END_MARKER_US);
        upload[idx++] = level_duration_make(true, (int32_t)KIA_V3_V4_END_MARKER_US);
    } else {
        upload[idx++] = level_duration_make(true, (int32_t)KIA_V3_V4_END_MARKER_US);
        upload[idx++] = level_duration_make(false, (int32_t)KIA_V3_V4_END_MARKER_US);
    }

    furi_check(idx == KIA_V3_V4_BURST_ENTRIES);
    instance->encoder.size_upload = idx;
    instance->encoder.front = 0;
}

SubGhzProtocolStatus
    subghz_protocol_encoder_kia_v3_v4_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV3V4* instance = context;

    instance->encoder.is_running = false;
    instance->encoder.front = 0;

    SubGhzProtocolStatus ret = SubGhzProtocolStatusError;

    flipper_format_rewind(flipper_format);

    do {
        FuriString* temp_str = furi_string_alloc();
        if(!flipper_format_read_string(flipper_format, "Protocol", temp_str)) {
            FURI_LOG_E(TAG, "Missing Protocol");
            furi_string_free(temp_str);
            break;
        }

        const char* proto_str = furi_string_get_cstr(temp_str);
        if(!furi_string_equal(temp_str, instance->base.protocol->name) &&
           strcmp(proto_str, "Kia V3") != 0 && strcmp(proto_str, "Kia V4") != 0) {
            FURI_LOG_E(TAG, "Wrong protocol %s", proto_str);
            furi_string_free(temp_str);
            break;
        }

        bool version_from_protocol_name = false;

        if(strcmp(proto_str, "Kia V3") == 0) {
            instance->version = 1;
            version_from_protocol_name = true;
        } else if(strcmp(proto_str, "Kia V4") == 0) {
            instance->version = 0;
            version_from_protocol_name = true;
        }

        furi_string_free(temp_str);

        flipper_format_rewind(flipper_format);
        uint32_t bits = 0;
        if(!flipper_format_read_uint32(flipper_format, "Bit", &bits, 1)) break;
        instance->generic.data_count_bit = 68;

        flipper_format_rewind(flipper_format);
        temp_str = furi_string_alloc();
        if(!flipper_format_read_string(flipper_format, "Key", temp_str)) {
            furi_string_free(temp_str);
            break;
        }

        const char* key_str = furi_string_get_cstr(temp_str);
        uint64_t key = 0;
        size_t str_len = strlen(key_str);
        size_t hex_pos = 0;
        for(size_t i = 0; i < str_len && hex_pos < 16; i++) {
            char c = key_str[i];
            if(c == ' ') continue;
            uint8_t nibble;
            if(c >= '0' && c <= '9') {
                nibble = c - '0';
            } else if(c >= 'A' && c <= 'F') {
                nibble = c - 'A' + 10;
            } else if(c >= 'a' && c <= 'f') {
                nibble = c - 'a' + 10;
            } else {
                break;
            }
            key = (key << 4) | nibble;
            hex_pos++;
        }
        furi_string_free(temp_str);

        if(hex_pos < 14) {
            FURI_LOG_E(TAG, "Invalid key: %zu nibbles", hex_pos);
            break;
        }
        instance->generic.data = key;

        uint32_t serial = UINT32_MAX;
        uint32_t btn = UINT32_MAX;
        uint32_t cnt = UINT32_MAX;

        flipper_format_rewind(flipper_format);
        flipper_format_read_uint32(flipper_format, "Serial", &serial, 1);
        flipper_format_rewind(flipper_format);
        flipper_format_read_uint32(flipper_format, "Btn", &btn, 1);
        flipper_format_rewind(flipper_format);
        flipper_format_read_uint32(flipper_format, "Cnt", &cnt, 1);

        if(serial == UINT32_MAX || btn == UINT32_MAX || cnt == UINT32_MAX) break;
        instance->serial = serial;
        instance->btn = (uint8_t)btn;
        instance->cnt = (uint16_t)cnt;
        instance->generic.serial = instance->serial;
        instance->generic.btn = instance->btn;
        instance->generic.cnt = instance->cnt;

        // [PROTOPIRATE_PORT] custom_btn support
        // Kia V3/V4 codes (see get_name_button): Lock=0x1, Unlock=0x2,
        // Trunk=0x3, Panic=0x4, Horn=0x8. The re-encode below reads
        // instance->btn, so remap it here before get_upload().
        {
            const uint8_t original_btn = (uint8_t)(instance->btn & 0x0FU);
            if(subghz_custom_btn_get_original() == 0) {
                subghz_custom_btn_set_original(original_btn);
            }
            subghz_custom_btn_set_max(4);
            uint8_t custom_btn_id = subghz_custom_btn_get();
            switch(custom_btn_id) {
            case SUBGHZ_CUSTOM_BTN_UP:    instance->btn = 0x1U;          break; // Lock
            case SUBGHZ_CUSTOM_BTN_OK:    instance->btn = original_btn;  break;
            case SUBGHZ_CUSTOM_BTN_DOWN:  instance->btn = 0x2U;          break; // Unlock
            case SUBGHZ_CUSTOM_BTN_LEFT:  instance->btn = 0x3U;          break; // Trunk
            case SUBGHZ_CUSTOM_BTN_RIGHT: instance->btn = 0x4U;          break; // Panic
            default:                      instance->btn = original_btn;  break;
            }
            instance->btn &= 0x0FU;
            instance->generic.btn = instance->btn;
        }

        // [ROLLING_CNT] Forward-encode the NEXT counter (like VAG/PSA) so the
        // transmitter UI shows an incrementing counter on each OK/D-pad press, then
        // persist "Cnt" so the decoder reads the advanced value on the UI refresh.
        {
            uint32_t mult = furi_hal_subghz_get_rolling_counter_mult();
            if(mult == 0U) mult = 1U;
            instance->cnt = (uint16_t)((instance->cnt + mult) & 0xFFFFU);
            instance->generic.cnt = instance->cnt;
            flipper_format_rewind(flipper_format);
            uint32_t cnt_store = instance->cnt;
            flipper_format_insert_or_update_uint32(flipper_format, "Cnt", &cnt_store, 1);
        }

        flipper_format_rewind(flipper_format);
        uint32_t version_temp;
        if(flipper_format_read_uint32(flipper_format, "KIAVersion", &version_temp, 1)) {
            if(!version_from_protocol_name) {
                instance->version = (uint8_t)version_temp;
            }
        } else if(!version_from_protocol_name) {
            instance->version = 0;
        }

        flipper_format_rewind(flipper_format);
        uint32_t repeat_temp = KIA_V3_V4_DEFAULT_REPEAT;
        flipper_format_read_uint32(flipper_format, "Repeat", &repeat_temp, 1);
        instance->encoder.repeat = (int32_t)repeat_temp;

        instance->crc_iter = 0;
        instance->bursts_sent = 0;

        subghz_protocol_encoder_kia_v3_v4_get_upload(instance);

        instance->encoder.is_running = true;
        instance->encoder.front = 0;

        ret = SubGhzProtocolStatusOk;
    } while(false);

    return ret;
}

void subghz_protocol_encoder_kia_v3_v4_stop(void* context) {
    if(!context) return;
    SubGhzProtocolEncoderKiaV3V4* instance = context;
    instance->encoder.is_running = false;
    instance->encoder.front = 0;
}

LevelDuration subghz_protocol_encoder_kia_v3_v4_yield(void* context) {
    SubGhzProtocolEncoderKiaV3V4* instance = context;

    if(!instance || !instance->encoder.upload || instance->encoder.repeat == 0 ||
       !instance->encoder.is_running) {
        if(instance) {
            instance->encoder.is_running = false;
        }
        return level_duration_reset();
    }

    if(instance->encoder.front >= instance->encoder.size_upload) {
        instance->encoder.is_running = false;
        instance->encoder.front = 0;
        return level_duration_reset();
    }

    LevelDuration ret = instance->encoder.upload[instance->encoder.front];

    if(++instance->encoder.front == instance->encoder.size_upload) {
        instance->crc_iter = (uint8_t)((instance->crc_iter + 1U) & 0x0FU);
        subghz_protocol_encoder_kia_v3_v4_patch_crc(instance);
        instance->encoder.front = 0;
        // Endless/breakless TX: while OK is held (endless_tx set by the transmit
        // scene) do not consume repeats, so the signal loops until release.
        if(!subghz_block_generic_global.endless_tx) instance->encoder.repeat--;
        if(instance->bursts_sent < KIA_V3_V4_CRC_SWEEP_COUNT) {
            instance->bursts_sent++;
        }
    }

    return ret;
}

void subghz_protocol_encoder_kia_v3_v4_set_button(void* context, uint8_t button) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV3V4* instance = context;
    instance->btn = button & 0x0F;
    instance->generic.btn = instance->btn;
    subghz_protocol_encoder_kia_v3_v4_get_upload(instance);
}

void subghz_protocol_encoder_kia_v3_v4_set_counter(void* context, uint16_t counter) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV3V4* instance = context;
    instance->cnt = counter;
    instance->generic.cnt = instance->cnt;
    subghz_protocol_encoder_kia_v3_v4_get_upload(instance);
}

void subghz_protocol_encoder_kia_v3_v4_increment_counter(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV3V4* instance = context;
    instance->cnt++;
    instance->generic.cnt = instance->cnt;
    subghz_protocol_encoder_kia_v3_v4_get_upload(instance);
}

uint16_t subghz_protocol_encoder_kia_v3_v4_get_counter(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV3V4* instance = context;
    return instance->cnt;
}

uint8_t subghz_protocol_encoder_kia_v3_v4_get_button(void* context) {
    furi_assert(context);
    SubGhzProtocolEncoderKiaV3V4* instance = context;
    return instance->btn;
}

// ============================================================================
// DECODER IMPLEMENTATION
// ============================================================================

void* subghz_protocol_decoder_kia_v3_v4_alloc(SubGhzEnvironment* environment) {
    UNUSED(environment);
    SubGhzProtocolDecoderKiaV3V4* instance = malloc(sizeof(SubGhzProtocolDecoderKiaV3V4));
    furi_assert(instance);

    instance->base.protocol = &subghz_protocol_kia_v3_v4;
    instance->generic.protocol_name = instance->base.protocol->name;
    return instance;
}

void subghz_protocol_decoder_kia_v3_v4_free(void* context) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV3V4* instance = context;
    free(instance);
}

void subghz_protocol_decoder_kia_v3_v4_reset(void* context) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV3V4* instance = context;
    instance->decoder.parser_step = KiaV3V4DecoderStepReset;
    instance->header_count = 0;
    instance->raw_bit_count = 0;
    instance->crc = 0;
    memset(instance->raw_bits, 0, sizeof(instance->raw_bits));
}

void subghz_protocol_decoder_kia_v3_v4_feed(void* context, bool level, uint32_t duration) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV3V4* instance = context;

    switch(instance->decoder.parser_step) {
    case KiaV3V4DecoderStepReset:
        if(level && (DURATION_DIFF(duration, subghz_protocol_kia_v3_v4_const.te_short) <
                     subghz_protocol_kia_v3_v4_const.te_delta)) {
            instance->decoder.parser_step = KiaV3V4DecoderStepCheckPreamble;
            instance->decoder.te_last = duration;
            instance->header_count = 1;
        }
        break;

    case KiaV3V4DecoderStepCheckPreamble:
        if(level) {
            if(DURATION_DIFF(duration, subghz_protocol_kia_v3_v4_const.te_short) <
               subghz_protocol_kia_v3_v4_const.te_delta) {
                instance->decoder.te_last = duration;
            } else if(duration > 1000 && duration < 1500) {
                if(instance->header_count >= 8) {
                    instance->decoder.parser_step = KiaV3V4DecoderStepCollectRawBits;
                    instance->raw_bit_count = 0;
                    instance->is_v3_sync = false;
                    memset(instance->raw_bits, 0, sizeof(instance->raw_bits));
                } else {
                    instance->decoder.parser_step = KiaV3V4DecoderStepReset;
                }
            } else {
                instance->decoder.parser_step = KiaV3V4DecoderStepReset;
            }
        } else {
            if(duration > 1000 && duration < 1500) {
                if(instance->header_count >= 8) {
                    instance->decoder.parser_step = KiaV3V4DecoderStepCollectRawBits;
                    instance->raw_bit_count = 0;
                    instance->is_v3_sync = true;
                    memset(instance->raw_bits, 0, sizeof(instance->raw_bits));
                } else {
                    instance->decoder.parser_step = KiaV3V4DecoderStepReset;
                }
            } else if(
                (DURATION_DIFF(duration, subghz_protocol_kia_v3_v4_const.te_short) <
                 subghz_protocol_kia_v3_v4_const.te_delta) &&
                (DURATION_DIFF(instance->decoder.te_last, subghz_protocol_kia_v3_v4_const.te_short) <
                 subghz_protocol_kia_v3_v4_const.te_delta)) {
                instance->header_count++;
            } else if(duration > 1500) {
                instance->decoder.parser_step = KiaV3V4DecoderStepReset;
            }
        }
        break;

    case KiaV3V4DecoderStepCollectRawBits:
        if(level) {
            if(duration > 1000 && duration < 1500) {
                if(kia_v3_v4_process_buffer(instance)) {
                    if(instance->base.callback)
                        instance->base.callback(&instance->base, instance->base.context);
                }
                instance->decoder.parser_step = KiaV3V4DecoderStepReset;
            } else if(
                DURATION_DIFF(duration, subghz_protocol_kia_v3_v4_const.te_short) <
                subghz_protocol_kia_v3_v4_const.te_delta) {
                kia_v3_v4_add_raw_bit(instance, false);
            } else if(
                DURATION_DIFF(duration, subghz_protocol_kia_v3_v4_const.te_long) <
                subghz_protocol_kia_v3_v4_const.te_delta) {
                kia_v3_v4_add_raw_bit(instance, true);
            } else {
                instance->decoder.parser_step = KiaV3V4DecoderStepReset;
            }
        } else {
            if(duration > 1000 && duration < 1500) {
                if(kia_v3_v4_process_buffer(instance)) {
                    if(instance->base.callback)
                        instance->base.callback(&instance->base, instance->base.context);
                }
                instance->decoder.parser_step = KiaV3V4DecoderStepReset;
            } else if(duration > 1500) {
                if(kia_v3_v4_process_buffer(instance)) {
                    if(instance->base.callback)
                        instance->base.callback(&instance->base, instance->base.context);
                }
                instance->decoder.parser_step = KiaV3V4DecoderStepReset;
            }
        }
        break;
    }
}

uint8_t subghz_protocol_decoder_kia_v3_v4_get_hash_data(void* context) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV3V4* instance = context;
    return subghz_protocol_blocks_get_hash_data(
        &instance->decoder, (instance->decoder.decode_count_bit / 8) + 1);
}

SubGhzProtocolStatus subghz_protocol_decoder_kia_v3_v4_serialize(
    void* context,
    FlipperFormat* flipper_format,
    SubGhzRadioPreset* preset) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV3V4* instance = context;

    // Serialize via the standard generic block FIRST. This writes the mandatory
    // Flipper file header (Filetype/Version) + Frequency + Preset + Protocol
    // (from generic.protocol_name = "KIA/HYU V3/V4") + Bit + Key, EXACTLY like the
    // working Kia siblings (kia_v5/kia_v2). The previous hand-rolled writer omitted
    // the header, which made saved files unloadable ("Cannot parse file") and broke
    // full-D-pad emulate ("Protocol not found!") and transmit. Then append the extra
    // Kia V3/V4 fields the deserialize reads.
    SubGhzProtocolStatus ret =
        subghz_block_generic_serialize(&instance->generic, flipper_format, preset);

    if(ret == SubGhzProtocolStatusOk) {
        uint32_t serial_tmp = instance->generic.serial;
        if(!flipper_format_write_uint32(flipper_format, "Serial", &serial_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t btn_tmp = instance->generic.btn;
        if(!flipper_format_write_uint32(flipper_format, "Btn", &btn_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t cnt_tmp = instance->generic.cnt;
        if(!flipper_format_write_uint32(flipper_format, "Cnt", &cnt_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        if(!flipper_format_write_uint32(flipper_format, "Encrypted", &instance->encrypted, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        if(!flipper_format_write_uint32(flipper_format, "Decrypted", &instance->decrypted, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t version_tmp = instance->version;
        if(!flipper_format_write_uint32(flipper_format, "KIAVersion", &version_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }
    if(ret == SubGhzProtocolStatusOk) {
        uint32_t crc_tmp = instance->crc;
        if(!flipper_format_write_uint32(flipper_format, "CRC", &crc_tmp, 1)) {
            ret = SubGhzProtocolStatusErrorParserOthers;
        }
    }

    return ret;
}

SubGhzProtocolStatus
    subghz_protocol_decoder_kia_v3_v4_deserialize(void* context, FlipperFormat* flipper_format) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV3V4* instance = context;

    // Tolerant bit-count check: serialize writes 68, but legacy .sub files may
    // carry 64 (stale min_count_bit_for_found). Accept both so old captures
    // still emulate instead of failing with "Error history parse.". Deserialize
    // without the framework's strict equality, then normalize to 68.
    SubGhzProtocolStatus ret =
        subghz_block_generic_deserialize(&instance->generic, flipper_format);
    if(ret == SubGhzProtocolStatusOk) {
        const uint16_t want = subghz_protocol_kia_v3_v4_const.min_count_bit_for_found; // 68
        if(instance->generic.data_count_bit == 64 ||
           instance->generic.data_count_bit == want) {
            instance->generic.data_count_bit = want; // normalize legacy 64 -> 68
        } else {
            ret = SubGhzProtocolStatusErrorValueBitCount;
        }
    }

    if(ret == SubGhzProtocolStatusOk) {
        uint32_t temp = 0;

        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Encrypted", &temp, 1)) {
            instance->encrypted = temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Decrypted", &temp, 1)) {
            instance->decrypted = temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "KIAVersion", &temp, 1)) {
            instance->version = (uint8_t)temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "CRC", &temp, 1)) {
            instance->crc = (uint8_t)temp;
        }

        // [ROLLING_CNT] Read Serial/Btn/Cnt so get_string shows the current values,
        // in particular the incremented counter the encoder re-wrote before the UI
        // refresh. (The decoder's live-decode path fills these from the frame; on
        // the transmitter refresh they only live in the fff.)
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Serial", &temp, 1)) {
            instance->generic.serial = temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Btn", &temp, 1)) {
            instance->generic.btn = (uint8_t)temp;
        }
        flipper_format_rewind(flipper_format);
        if(flipper_format_read_uint32(flipper_format, "Cnt", &temp, 1)) {
            instance->generic.cnt = temp;
        }
    }

    return ret;
}

static const char* subghz_protocol_kia_v3_v4_get_name_button(uint8_t btn) {
    switch(btn) {
    case 0x1:
        return "Lock";
    case 0x2:
        return "Unlock";
    case 0x3:
        return "Trunk";
    case 0x4:
        return "Panic";
    case 0x8:
        return "Horn";
    default:
        return "Unknown";
    }
}

// [PROTOPIRATE_PORT] custom_btn UI support
// Map the current D-pad selection to a Kia V3/V4 button code, mirroring the
// encoder remap (see encoder deserialize): Up=Lock(0x1), Down=Unlock(0x2),
// Left=Trunk(0x3), Right=Panic(0x4), OK=captured.
static uint8_t kia_v3_v4_ui_button(uint8_t custom, uint8_t original_btn) {
    switch(custom) {
    case SUBGHZ_CUSTOM_BTN_UP:
        return 0x1U; // Lock
    case SUBGHZ_CUSTOM_BTN_DOWN:
        return 0x2U; // Unlock
    case SUBGHZ_CUSTOM_BTN_LEFT:
        return 0x3U; // Trunk
    case SUBGHZ_CUSTOM_BTN_RIGHT:
        return 0x4U; // Panic
    case SUBGHZ_CUSTOM_BTN_OK:
    default:
        return original_btn;
    }
}

void subghz_protocol_decoder_kia_v3_v4_get_string(void* context, FuriString* output) {
    furi_assert(context);
    SubGhzProtocolDecoderKiaV3V4* instance = context;

    uint32_t key_hi = (uint32_t)(instance->generic.data >> 32);
    uint32_t key_lo = (uint32_t)(instance->generic.data & 0xFFFFFFFF);

    // [BUGFIX UI] Re-derive the displayed button from the current D-pad
    // selection so the transmitter UI reflects subghz_custom_btn_get() (like
    // psa.c/star_line.c). CRC shown is the captured frame's CRC (no OK/BAD flag);
    // the encoder recomputes the real CRC for the transmitted button.
    subghz_custom_btn_set_max(4);
    uint8_t display_btn = (uint8_t)instance->generic.btn;
    uint8_t custom_btn_id = subghz_custom_btn_get();
    if(custom_btn_id != SUBGHZ_CUSTOM_BTN_OK) {
        display_btn = kia_v3_v4_ui_button(custom_btn_id, (uint8_t)instance->generic.btn);
    }

    furi_string_cat_printf(
        output,
        "%s %dbit\r\n"
        "Key:0x%08lX%08lX\r\n"
        "SN:0x%07lX Btn:[%s]\r\n"
        "CRC:%01X Cnt:%04lX\r\n",
        kia_version_names[instance->version],
        instance->generic.data_count_bit,
        key_hi,
        key_lo,
        instance->generic.serial,
        subghz_protocol_kia_v3_v4_get_name_button(display_btn),
        instance->crc,
        instance->generic.cnt);
}
