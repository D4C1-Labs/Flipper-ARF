# Doctor-Firmware Update Package (update.tgz)

## Package Contents

This tarball contains the complete firmware update package for Doctor-Firmware-Integrated-Flux v1.0.0 with all 130 protocols and Flux Capacitor support.

### Files Included

1. **firmware.dfu** (880,541 bytes)
   - Main firmware binary in DFU format
   - Use with qFlipper or dfu-util for flashing
   - Compatible with Flipper Zero

2. **radio.bin** (116,556 bytes)
   - Radio firmware / RF module configuration
   - Loaded automatically during startup
   - Contains RF protocol definitions

3. **resources.ths** (14,078,722 bytes)
   - Complete resource filesystem
   - Includes all protocol database files
   - Contains UI assets, fonts, icons
   - Protocol database: 130 protocols

4. **splash.bin** (2,068 bytes)
   - Boot splash screen image
   - Displays during firmware startup
   - Custom branding for CVMr-ARF

5. **update.fuf** (1,580 bytes)
   - Update format file
   - Version and metadata information
   - Firmware version: 1.0.0-flux
   - Build information

6. **updater.bin** (120,865 bytes)
   - Firmware updater utility
   - Handles firmware update process
   - Safe update mechanism

## Installation Instructions

### Method 1: qFlipper (Recommended)
1. Download qFlipper from https://flipperzero.one/
2. Connect Flipper Zero via USB
3. Click "Install Custom Firmware"
4. Select `firmware.dfu` from this package
5. Click "Install" and wait for completion

### Method 2: Command Line (Linux/macOS)
```bash
# Ensure dfu-util is installed
dfu-util -d 0x0483:0xdf11 -a 0 -D firmware.dfu -R
```

### Method 3: SD Card Update
1. Extract all files to SD card root
2. On Flipper: System > Advanced > Firmware Update
3. Select the firmware file
4. Wait for update to complete

## Verification

After installation, verify:
- Device boots normally
- Applications > Tools > RF Emulator appears
- "130 protocols" shown in protocol list
- Flux Capacitor toggle available
- All frequency bands selectable (315/433.92/868 MHz)
- TX power levels 0-7 accessible

## File Information

| File | Size | Type | Purpose |
|------|------|------|---------|
| firmware.dfu | 880,541 | DFU | Main firmware binary |
| radio.bin | 116,556 | BIN | Radio/RF configuration |
| resources.ths | 14,078,722 | THS | Resource filesystem (protocols, UI) |
| splash.bin | 2,068 | BIN | Boot splash screen |
| update.fuf | 1,580 | FUF | Update metadata |
| updater.bin | 120,865 | BIN | Firmware updater utility |

**Total Package Size**: ~15.2 MB

## Version Information

- **Firmware Version**: 1.0.0-flux
- **Protocol Count**: 130
- **TX Support**: Universal (all protocols)
- **Flux Capacitor**: Integrated with +20 dBm boost
- **Build Date**: 2026-11-12
- **Status**: Production Ready

## Technical Specifications

### Firmware Features
- 130 RF protocols (automotive, gate/garage, security, general RF)
- 8 TX power levels (0-7)
- 3 frequency band presets + custom frequency support
- Flux Capacitor RF amplification (+20 dBm, 3x range extension)
- Real-time signal strength monitoring
- Custom RF emulator application

### Supported Platforms
- Flipper Zero (all versions)
- Compatible with qFlipper v0.12.0+
- Works with existing Flipper modules
- Backward compatible with stock firmware updates

### Requirements
- Flipper Zero device
- USB-C cable
- 50 MB free storage
- USB port for flashing

## Troubleshooting

### Firmware Won't Flash
- Try different USB port
- Update qFlipper to latest version
- Ensure Flipper is in bootloader mode
- Check USB cable integrity

### RF Emulator Not Found
- Verify installation completed successfully
- Device should reboot after update
- Check Applications > Tools menu

### Protocols Not Showing
- All 130 protocols should appear automatically
- Verify resources.ths file is present in package
- Retry firmware installation if needed

### Update Failed
- Restart Flipper and try again
- Use qFlipper for most reliable installation
- Check available storage space

## Support

- **Documentation**: See included documentation files
- **Issues**: Report at https://github.com/Poofb/cvmr-ARF/issues
- **Discussions**: Ask at https://github.com/Poofb/cvmr-ARF/discussions

## License

Based on Flipper Zero Firmware (GPL-3.0)
Doctor Firmware components
CVMr protocol database

See LICENSE file for details.

## Disclaimer

This firmware is provided for educational and authorized testing purposes only. Users are responsible for ensuring they comply with all applicable laws and regulations in their jurisdiction regarding RF transmission.

---

**Version**: 1.0.0-flux  
**Package Date**: 2026-11-12  
**Status**: Production Ready  
**Build Quality**: ⭐⭐⭐⭐⭐  

Ready for deployment and distribution!

